"""
奖励单调性检查模块

验证奖励系统是否尊重法律因果关系，
确保在证据状态演进过程中奖励值符合单调性约束。
"""

from typing import List, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum


class MonotonicityViolation(Enum):
    """单调性违反类型"""
    INCREASING_EXPECTED = "increasing_expected"      # 期望递增但实际未递增
    DECREASING_EXPECTED = "decreasing_expected"      # 期望递减但实际未递减
    NON_MONOTONIC = "non_monotonic"                  # 非单调变化
    SEVERE_VIOLATION = "severe_violation"            # 严重违反


@dataclass
class MonotonicityCheck:
    """单调性检查结果"""
    case_id: str
    evidence_snapshots: List[str]
    reward_values: List[float]
    violations: List[Tuple[int, int, MonotonicityViolation, str]]
    legal_principle: str
    expected_direction: str  # "increasing" 或 "decreasing"


class RewardMonotonicityChecker:
    """奖励单调性检查器"""
    
    def __init__(self):
        # 延迟导入避免循环依赖
        from ..logic_core.evidence.evidence_state import EvidenceState
        from ..logic_core.legal_reasoning.syllogism_evaluator import SyllogismEvaluator
        from ..logic_core.reward.reward_adapter import RewardAdapter
        
        self.syllogism_evaluator = SyllogismEvaluator()
        self.reward_adapter = RewardAdapter()
    
    def check_monotonicity(self) -> List[MonotonicityCheck]:
        """
        执行单调性检查
        
        Returns:
            单调性检查结果列表
        """
        print("开始奖励单调性检查...")
        
        # 定义代表性测试案例
        test_cases = self._define_test_cases()
        
        results = []
        for case in test_cases:
            print(f"检查案例: {case['case_id']}")
            result = self._check_single_case(case)
            if result:
                results.append(result)
                self._print_case_result(result)
        
        # 输出总体统计
        self._print_summary(results)
        
        return results
    
    def _define_test_cases(self) -> List[Dict[str, Any]]:
        """定义测试案例"""
        return [
            {
                "case_id": "illegal_termination_strengthening",
                "legal_principle": "非法解除劳动合同证据强化",
                "expected_direction": "decreasing",  # 员工胜诉概率增加，奖励应该递减（负值变小）
                "snapshots": self._create_illegal_termination_snapshots()
            },
            {
                "case_id": "mutual_agreement_weakening",
                "legal_principle": "协商解除劳动合同证据削弱",
                "expected_direction": "increasing",  # 协商解除被否定，员工胜诉概率增加，奖励应该递增
                "snapshots": self._create_mutual_agreement_snapshots()
            },
            {
                "case_id": "procedural_violation_strengthening",
                "legal_principle": "程序违法证据强化",
                "expected_direction": "decreasing",  # 程序违法证据增加，用人单位责任加重，奖励应该递减
                "snapshots": self._create_procedural_violation_snapshots()
            }
        ]
    
    def _create_illegal_termination_snapshots(self) -> List[Dict[str, Any]]:
        """创建非法解除劳动合同的证据快照序列"""
        from ..logic_core.evidence.evidence_state import EvidenceState
        
        snapshots = []
        
        # 快照1：初始状态，证据很少
        state1 = EvidenceState()
        state1.written_contract_violation = None
        state1.legal_procedure_compliance = None
        snapshots.append({
            "description": "初始状态：证据不足",
            "evidence_state": state1,
            "reason": "仅有基本的合同违反指控，缺乏具体证据"
        })
        
        # 快照2：证据部分显现
        state2 = EvidenceState()
        state2.written_contract_violation = True
        state2.legal_procedure_compliance = None
        snapshots.append({
            "description": "证据显现：确认合同违反",
            "evidence_state": state2,
            "reason": "确认了书面合同条款违反，但程序合规性仍未知"
        })
        
        # 快照3：证据充分
        state3 = EvidenceState()
        state3.written_contract_violation = True
        state3.legal_procedure_compliance = False  # 程序不合规
        state3.unilateral_job_change = True
        snapshots.append({
            "description": "证据充分：多项违法情形",
            "evidence_state": state3,
            "reason": "多项证据表明用人单位违法解除劳动合同"
        })
        
        return snapshots
    
    def _create_mutual_agreement_snapshots(self) -> List[Dict[str, Any]]:
        """创建协商解除劳动合同的证据快照序列"""
        from ..logic_core.evidence.evidence_state import EvidenceState
        
        snapshots = []
        
        # 快照1：初始状态，看似协商解除
        state1 = EvidenceState()
        state1.negotiated_separation = True
        state1.forced_resignation_pressure = None
        snapshots.append({
            "description": "初始状态：表面协商解除",
            "evidence_state": state1,
            "reason": "表面显示双方协商一致解除劳动合同"
        })
        
        # 快照2：出现矛盾证据
        state2 = EvidenceState()
        state2.negotiated_separation = True
        state2.forced_resignation_pressure = True  # 发现强迫辞职压力
        snapshots.append({
            "description": "出现矛盾：强迫辞职压力",
            "evidence_state": state2,
            "reason": "虽然有协商协议，但发现存在强迫辞职压力"
        })
        
        # 快照3：矛盾证据占主导
        state3 = EvidenceState()
        state3.negotiated_separation = False  # 协商解除被否定
        state3.forced_resignation_pressure = True
        state3.workplace_harassment = True
        snapshots.append({
            "description": "矛盾证据主导：否定协商解除",
            "evidence_state": state3,
            "reason": "强迫辞职和职场骚扰证据占主导，协商解除不成立"
        })
        
        return snapshots
    
    def _create_procedural_violation_snapshots(self) -> List[Dict[str, Any]]:
        """创建程序违法的证据快照序列"""
        from ..logic_core.evidence.evidence_state import EvidenceState
        
        snapshots = []
        
        # 快照1：程序状态未知
        state1 = EvidenceState()
        state1.legal_procedure_compliance = None
        snapshots.append({
            "description": "初始状态：程序状态未知",
            "evidence_state": state1,
            "reason": "解除劳动合同程序是否合规尚未明确"
        })
        
        # 快照2：程序初步合规
        state2 = EvidenceState()
        state2.legal_procedure_compliance = True
        state2.written_contract_violation = True
        snapshots.append({
            "description": "程序初步合规但实体违法",
            "evidence_state": state2,
            "reason": "虽然程序合规，但存在实体违法行为"
        })
        
        # 快照3：程序严重违法
        state3 = EvidenceState()
        state3.legal_procedure_compliance = False  # 程序不合规
        state3.written_contract_violation = True
        state3.social_insurance_violation = True
        snapshots.append({
            "description": "程序严重违法：双重违法",
            "evidence_state": state3,
            "reason": "程序不合规加上其他违法行为，用人单位责任更重"
        })
        
        return snapshots
    
    def _check_single_case(self, case: Dict[str, Any]) -> MonotonicityCheck:
        """检查单个案例的单调性"""
        evidence_snapshots = []
        reward_values = []
        violations = []
        
        # 计算每个快照的奖励值
        for i, snapshot in enumerate(case["snapshots"]):
            evidence_snapshots.append(snapshot["description"])
            
            # 运行奖励适配器
            element_results = self.syllogism_evaluator.element_matcher.get_detailed_analysis(
                snapshot["evidence_state"]
            )
            reasoning_result = self.syllogism_evaluator.evaluate(
                snapshot["evidence_state"], element_results
            )
            reward_result = self.reward_adapter.adapt(reasoning_result)
            
            reward_values.append(reward_result.total_reward)
            
            # 检查与前一状态的单调性
            if i > 0:
                violation = self._check_monotonicity_violation(
                    case["expected_direction"],
                    reward_values[i-1], 
                    reward_values[i],
                    i-1, i
                )
                if violation:
                    violations.append((
                        i-1, i, violation[0], 
                        f"{violation[1]} (从 {reward_values[i-1]:.3f} 到 {reward_values[i]:.3f})"
                    ))
        
        return MonotonicityCheck(
            case_id=case["case_id"],
            evidence_snapshots=evidence_snapshots,
            reward_values=reward_values,
            violations=violations,
            legal_principle=case["legal_principle"],
            expected_direction=case["expected_direction"]
        )
    
    def _check_monotonicity_violation(self, expected_direction: str, 
                                    prev_reward: float, curr_reward: float,
                                    prev_idx: int, curr_idx: int) -> Tuple[MonotonicityViolation, str]:
        """
        检查单调性违反
        """
        if expected_direction == "decreasing":
            # 期望递减（如非法解除证据强化时，员工胜诉概率增加，负奖励应减少）
            if curr_reward >= prev_reward:  # 实际未递减
                if curr_reward > prev_reward:
                    return (MonotonicityViolation.DECREASING_EXPECTED, 
                           f"违反递减预期：奖励从{prev_reward:.3f}增加到{curr_reward:.3f}")
                else:
                    return (MonotonicityViolation.NON_MONOTONIC,
                           f"非严格递减：奖励值未变化")
        
        elif expected_direction == "increasing":
            # 期望递增（如协商解除被否定时，员工胜诉概率增加，负奖励应减少即向正值增加）
            if curr_reward <= prev_reward:  # 实际未递增
                if curr_reward < prev_reward:
                    return (MonotonicityViolation.INCREASING_EXPECTED,
                           f"违反递增预期：奖励从{prev_reward:.3f}减少到{curr_reward:.3f}")
                else:
                    return (MonotonicityViolation.NON_MONOTONIC,
                           f"非严格递增：奖励值未变化")
        
        return None  # 没有违反
    
    def _print_case_result(self, result: MonotonicityCheck):
        """打印案例检查结果"""
        print(f"\n--- 案例: {result.case_id} ---")
        print(f"法律原则: {result.legal_principle}")
        print(f"预期变化方向: {result.expected_direction}")
        
        print("证据状态演化与奖励值:")
        for i, (snapshot, reward) in enumerate(zip(result.evidence_snapshots, result.reward_values)):
            status = "✓" if not result.violations or not any(v[0] <= i <= v[1] for v in result.violations) else "✗"
            print(f"  {status} 快照{i+1}: {snapshot}")
            print(f"     奖励值: {reward:.3f}")
        
        if result.violations:
            print("\n违反单调性约束:")
            for violation in result.violations:
                print(f"  在从快照{violation[0]+1}到快照{violation[1]+1}过程中:")
                print(f"    违反类型: {violation[2].value}")
                print(f"    详细描述: {violation[3]}")
        else:
            print("\n✓ 所有状态转移均符合单调性约束")
    
    def _print_summary(self, results: List[MonotonicityCheck]):
        """打印汇总结果"""
        total_violations = sum(len(result.violations) for result in results)
        total_transitions = sum(len(result.reward_values) - 1 for result in results)
        
        print("\n" + "="*60)
        print("单调性检查总体结果")
        print("="*60)
        print(f"测试案例数: {len(results)}")
        print(f"总状态转移数: {total_transitions}")
        print(f"违反数: {total_violations}")
        
        if total_transitions > 0:
            compliance_rate = (1 - total_violations / total_transitions) * 100
            print(f"符合率: {compliance_rate:.1f}%")
        
        if total_violations == 0:
            print("✓ 恭喜！所有单调性约束都得到了满足")
        else:
            print("✗ 发现单调性违反，请检查奖励系统逻辑")
            
            # 分析违反类型
            violation_types = {}
            for result in results:
                for violation in result.violations:
                    violation_type = violation[2].value
                    violation_types[violation_type] = violation_types.get(violation_type, 0) + 1
            
            print("\n违反类型分布:")
            for vtype, count in violation_types.items():
                print(f"  {vtype}: {count}次")


# 使用示例
def run_monotonicity_check():
    """运行单调性检查"""
    checker = RewardMonotonicityChecker()
    results = checker.check_monotonicity()
    return results


# 如果直接运行此模块
if __name__ == "__main__":
    run_monotonicity_check()