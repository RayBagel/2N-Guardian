"""
奖励系统诊断干运行模块

对现有真实和合成对话进行奖励计算的完整流程测试，
不涉及任何训练过程。
"""

import json
import csv
from typing import List, Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass
from collections import defaultdict


@dataclass
class DiagnosticResult:
    """诊断结果数据类"""
    case_id: str
    ground_truth: str  # "win" 或 "lose"
    verdict_tendency: str  # 推理得出的判决倾向
    total_reward: float
    reward_breakdown: Dict[str, float]
    reasoning_trace: str
    processing_time: float


class RewardDryRunDiagnostics:
    """奖励系统干运行诊断类"""
    
    def __init__(self):
        # 延迟导入避免循环依赖
        from ..logic_core.evidence.evidence_tracker import EvidenceTracker
        from ..logic_core.evidence.evidence_state import EvidenceState
        from ..logic_core.legal_reasoning.element_matcher import LegalElementMatcher
        from ..logic_core.legal_reasoning.syllogism_evaluator import SyllogismEvaluator
        from ..logic_core.reward.reward_adapter import RewardAdapter
        
        self.evidence_tracker = EvidenceTracker()
        self.element_matcher = LegalElementMatcher()
        self.syllogism_evaluator = SyllogismEvaluator()
        self.reward_adapter = RewardAdapter()
    
    def run_diagnostics(self, dialogues_file: str, output_csv: Optional[str] = None) -> Dict[str, Any]:
        """
        运行诊断测试
        
        Args:
            dialogues_file: 对话数据文件路径 (JSONL格式)
            output_csv: 可选的CSV输出文件路径
            
        Returns:
            统计结果字典
        """
        print("开始奖励系统诊断干运行...")
        print(f"加载对话文件: {dialogues_file}")
        
        # 加载对话数据
        dialogues = self._load_dialogues(dialogues_file)
        print(f"加载了 {len(dialogues)} 个对话案例")
        
        if not dialogues:
            print("错误: 没有找到有效的对话数据")
            return {}
        
        # 处理每个对话
        results = []
        for i, dialogue in enumerate(dialogues):
            print(f"处理第 {i+1}/{len(dialogues)} 个案例: {dialogue.get('case_id', 'unknown')}")
            
            result = self._process_single_dialogue(dialogue)
            if result:
                results.append(result)
                print(f"  结果: 真实结果={result.ground_truth}, 推理结果={result.verdict_tendency}, "
                      f"奖励={result.total_reward:.3f}")
        
        # 计算统计信息
        statistics = self._calculate_statistics(results)
        
        # 输出结果
        self._print_summary(results, statistics)
        
        # 可选：输出CSV文件
        if output_csv:
            self._export_to_csv(results, output_csv)
            print(f"结果已导出到: {output_csv}")
        
        return statistics
    
    def _load_dialogues(self, file_path: str) -> List[Dict[str, Any]]:
        """加载对话数据"""
        dialogues = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    try:
                        dialogue = json.loads(line.strip())
                        if self._validate_dialogue_format(dialogue):
                            dialogues.append(dialogue)
                        else:
                            print(f"警告: 第{line_num}行对话格式无效，已跳过")
                    except json.JSONDecodeError as e:
                        print(f"警告: 第{line_num}行JSON解析错误: {e}")
        except FileNotFoundError:
            print(f"错误: 找不到文件 {file_path}")
        except Exception as e:
            print(f"错误: 读取文件时发生错误: {e}")
        
        return dialogues
    
    def _validate_dialogue_format(self, dialogue: Dict[str, Any]) -> bool:
        """验证对话格式"""
        required_fields = ['case_id', 'system', 'user', 'assistant']
        # ground_truth 字段可选，但建议包含
        
        return all(field in dialogue for field in required_fields[:3])  # system, user, assistant 是必需的
        # case_id 如果没有，会生成默认值
    
    def _process_single_dialogue(self, dialogue: Dict[str, Any]) -> Optional[DiagnosticResult]:
        """处理单个对话"""
        import time
        start_time = time.time()
        
        try:
            # 提取案例ID和真实结果
            case_id = dialogue.get('case_id', f'case_{hash(str(dialogue))}')
            ground_truth = dialogue.get('outcome', 'unknown')  # 从数据中提取真实结果
            
            # 构建对话回合
            dialogue_turn = {
                'system': dialogue.get('system', ''),
                'user': dialogue.get('user', ''),
                'assistant': dialogue.get('assistant', '')
            }
            
            # 步骤1: 运行证据追踪器
            initial_evidence_state = self.evidence_tracker.evidence_state.EvidenceState()
            evidence_state = self.evidence_tracker.update(initial_evidence_state, dialogue_turn)
            
            # 步骤2: 运行要素匹配器
            element_results = self.element_matcher.get_detailed_analysis(evidence_state)
            
            # 步骤3: 运行三段论评估器
            reasoning_result = self.syllogism_evaluator.evaluate(evidence_state, element_results)
            
            # 步骤4: 运行奖励适配器
            reward_result = self.reward_adapter.adapt(reasoning_result)
            
            processing_time = time.time() - start_time
            
            return DiagnosticResult(
                case_id=case_id,
                ground_truth=ground_truth,
                verdict_tendency=reasoning_result.verdict.value,
                total_reward=reward_result.total_reward,
                reward_breakdown=reward_result.components,
                reasoning_trace=reasoning_result.reasoning_explanation,
                processing_time=processing_time
            )
            
        except Exception as e:
            print(f"处理案例 {dialogue.get('case_id', 'unknown')} 时出错: {e}")
            return None
    
    def _calculate_statistics(self, results: List[DiagnosticResult]) -> Dict[str, Any]:
        """计算统计信息"""
        if not results:
            return {}
        
        stats = {
            'total_cases': len(results),
            'reward_by_ground_truth': defaultdict(list),
            'accuracy': defaultdict(int),
            'confusion_matrix': defaultdict(lambda: defaultdict(int)),
            'average_processing_time': 0.0,
            'reward_ranges': {
                'min': float('inf'),
                'max': float('-inf'),
                'avg': 0.0
            }
        }
        
        total_time = 0.0
        total_reward = 0.0
        
        for result in results:
            # 按真实结果分类统计奖励
            stats['reward_by_ground_truth'][result.ground_truth].append(result.total_reward)
            
            # 准确性统计（简化版本）
            if result.ground_truth == result.verdict_tendency:
                stats['accuracy'][result.ground_truth] += 1
            
            # 混淆矩阵
            stats['confusion_matrix'][result.ground_truth][result.verdict_tendency] += 1
            
            # 时间统计
            total_time += result.processing_time
            
            # 奖励范围统计
            stats['reward_ranges']['min'] = min(stats['reward_ranges']['min'], result.total_reward)
            stats['reward_ranges']['max'] = max(stats['reward_ranges']['max'], result.total_reward)
            total_reward += result.total_reward
        
        # 计算平均值
        stats['average_processing_time'] = total_time / len(results)
        stats['reward_ranges']['avg'] = total_reward / len(results)
        
        return stats
    
    def _print_summary(self, results: List[DiagnosticResult], statistics: Dict[str, Any]):
        """打印汇总信息"""
        print("\n" + "="*60)
        print("奖励系统诊断结果汇总")
        print("="*60)
        
        if not results:
            print("没有有效的结果数据")
            return
        
        print(f"总案例数: {statistics['total_cases']}")
        print(f"平均处理时间: {statistics['average_processing_time']:.4f}秒")
        print(f"奖励范围: [{statistics['reward_ranges']['min']:.3f}, {statistics['reward_ranges']['max']:.3f}]")
        print(f"平均奖励: {statistics['reward_ranges']['avg']:.3f}")
        
        print("\n按真实结果分类的奖励统计:")
        for gt, rewards in statistics['reward_by_ground_truth'].items():
            if rewards:
                avg_reward = sum(rewards) / len(rewards)
                print(f"  {gt}: 平均奖励 = {avg_reward:.3f}, 样本数 = {len(rewards)}")
        
        print("\n准确率统计:")
        total_correct = sum(statistics['accuracy'].values())
        accuracy = total_correct / len(results) * 100 if results else 0
        print(f"  总体准确率: {accuracy:.1f}% ({total_correct}/{len(results)})")
        
        print("\n混淆矩阵:")
        for gt, predictions in statistics['confusion_matrix'].items():
            print(f"  真实{gt}:")
            for pred, count in predictions.items():
                print(f"    预测为{pred}: {count}")
    
    def _export_to_csv(self, results: List[DiagnosticResult], csv_path: str):
        """导出结果到CSV文件"""
        try:
            with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['case_id', 'ground_truth', 'verdict_tendency', 'total_reward', 
                            'processing_time', 'reward_base', 'reward_missing', 'reward_factors']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for result in results:
                    row = {
                        'case_id': result.case_id,
                        'ground_truth': result.ground_truth,
                        'verdict_tendency': result.verdict_tendency,
                        'total_reward': result.total_reward,
                        'processing_time': result.processing_time,
                        'reward_base': result.reward_breakdown.get('base_reward', 0),
                        'reward_missing': result.reward_breakdown.get('missing_penalty', 0),
                        'reward_factors': result.reward_breakdown.get('factor_adjustment', 0)
                    }
                    writer.writerow(row)
        except Exception as e:
            print(f"导出CSV时出错: {e}")


# 使用示例
def run_reward_diagnostics():
    """运行奖励系统诊断"""
    diagnostics = RewardDryRunDiagnostics()
    
    # 示例使用
    # 使用已存在的训练数据文件
    data_file = "/Users/apple/2N-Guardian/data/train.jsonl"
    csv_output = "/Users/apple/2N-Guardian/data/reward_diagnostics.csv"
    
    # 如果文件不存在，创建一个简单的测试数据
    if not Path(data_file).exists():
        print("未找到训练数据文件，创建测试数据...")
        _create_sample_data(data_file)
    
    # 运行诊断
    statistics = diagnostics.run_diagnostics(data_file, csv_output)
    
    return statistics


def _create_sample_data(file_path: str):
    """创建示例测试数据"""
    sample_data = [
        {
            "case_id": "test_case_1_win",
            "system": "你是一个法律博弈专家。",
            "user": "请提供胜诉策略。",
            "assistant": "员工应当坚持自己的合法权益，要求用人单位提供解除合同的法定依据...",
            "outcome": "win"
        },
        {
            "case_id": "test_case_2_lose",
            "system": "你是一个法律救援专家。",
            "user": "请提供避免败诉的策略。",
            "assistant": "员工应认识到协商一致解除合同的法律后果，寻求和解...",
            "outcome": "lose"
        }
    ]
    
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            for case in sample_data:
                f.write(json.dumps(case, ensure_ascii=False) + '\n')
        print(f"已创建示例数据文件: {file_path}")
    except Exception as e:
        print(f"创建示例数据失败: {e}")


# 如果直接运行此模块
if __name__ == "__main__":
    run_reward_diagnostics()