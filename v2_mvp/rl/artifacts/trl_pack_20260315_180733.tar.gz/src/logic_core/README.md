# Logic Core - 奖励系统

本模块实现了法律AI系统的奖励机制，用于评估助手回复的法律准确性。

## 模块结构

### reward_components/
包含各类法律要素的奖励计算组件：

- `evidence.py` - 证据收集策略奖励
- `burden.py` - 举证责任分析奖励
- `illegality.py` - 违法性识别奖励
- `penalties.py` - 处罚后果分析奖励

### reward_aggregator.py
聚合各组件的奖励分数，生成总体奖励分数。

## 设计理念

奖励系统基于劳动法律专业知识设计，确保AI助手的回复在法律上准确、实用。