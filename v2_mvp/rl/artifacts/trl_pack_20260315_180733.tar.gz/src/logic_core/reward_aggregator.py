def aggregate_rewards(evidence_score: float, burden_score: float, illegality_score: float, penalties_score: float) -> float:
    """
    在法律上代表：综合各项法律要素的得分，计算总体奖励分数
    输入：evidence_score（证据得分）、burden_score（举证责任得分）、illegality_score（违法性得分）、penalties_score（处罚后果得分）
    输出：float reward（0.0-1.0之间的综合奖励分数）
    """
    pass


def calculate_total_reward(assistant_response: str) -> float:
    """
    在法律上代表：基于助手回复计算完整的法律奖励分数
    输入：assistant 回复字符串（助手对法律问题的完整分析和建议）
    输出：float reward（0.0-1.0之间的总奖励分数）
    """
    pass