"""
证据模式定义模块

在非法解除劳动关系案件中，劳动仲裁员或法官通常依赖的证据类型。
此模块定义了结构化的证据模式，用于指导AI系统识别和评估证据的有效性。
"""

# 证据模式定义
EVIDENCE_SCHEMA = {
    "written_contract_violation": {
        "name": "书面合同条款违反",
        "description": "用人单位单方面违反劳动合同约定的条款，如工作地点、岗位、薪资等",
        "typical_sources": ["劳动合同", "公司通知", "书面变更协议"],
        "supports": "employee"  # 支持员工方
    },
    "verbal_agreement_breach": {
        "name": "口头约定违反",
        "description": "用人单位违背与员工的口头约定，特别是在招聘或入职时的承诺",
        "typical_sources": ["录音", "证人证言", "聊天记录"],
        "supports": "employee"
    },
    "discipline_policy_abuse": {
        "name": "纪律处分滥用",
        "description": "用人单位不当使用纪律处分程序，或对轻微违规进行过度处罚",
        "typical_sources": ["处罚通知书", "规章制度", "同类案例对比"],
        "supports": "employee"
    },
    "workplace_harassment": {
        "name": "职场骚扰或恶意刁难",
        "description": "用人单位通过言语或行为对员工进行骚扰或恶意刁难，迫使员工离职",
        "typical_sources": ["录音录像", "医疗记录", "证人证言", "聊天记录"],
        "supports": "employee"
    },
    "unilateral_job_change": {
        "name": "单方面岗位调整",
        "description": "用人单位未经员工同意单方面调整工作岗位或工作内容",
        "typical_sources": ["岗位调整通知", "新岗位描述", "工资单变化"],
        "supports": "employee"
    },
    "forced_resignation_pressure": {
        "name": "强迫辞职压力",
        "description": "用人单位通过各种手段强迫员工主动辞职",
        "typical_sources": ["录音", "聊天记录", "邮件往来", "证人证言"],
        "supports": "employee"
    },
    "salary_withholding": {
        "name": "工资扣押或克扣",
        "description": "用人单位无正当理由扣押或克扣员工工资",
        "typical_sources": ["工资单", "银行流水", "财务记录", "通知函"],
        "supports": "employee"
    },
    "social_insurance_violation": {
        "name": "社保公积金违规",
        "description": "用人单位未按规定缴纳或违规操作员工的社会保险和公积金",
        "typical_sources": ["社保缴费记录", "公积金记录", "官方证明"],
        "supports": "employee"
    },
    "overtime_without_compensation": {
        "name": "加班无补偿",
        "description": "用人单位要求员工长期加班但不给予法定补偿",
        "typical_sources": ["考勤记录", "工作日志", "证人证言", "工作成果"],
        "supports": "employee"
    },
    "severe_disciplinary_action": {
        "name": "严重违纪行为",
        "description": "员工确实存在严重违反公司规章制度的行为",
        "typical_sources": ["调查报告", "证人证言", "监控录像", "书面承认"],
        "supports": "employer"  # 支持用人单位
    },
    "performance_deficiency": {
        "name": "业绩不达标",
        "description": "员工经过培训或调岗后仍不能胜任工作的证据",
        "typical_sources": ["绩效评估", "培训记录", "调岗通知", "考核标准"],
        "supports": "employer"
    },
    "company_closure_restructuring": {
        "name": "公司关闭或重组",
        "description": "因企业转产、重大技术革新或经营方式调整导致的人员裁减",
        "typical_sources": ["董事会决议", "重组公告", "政府批准文件", "财务报表"],
        "supports": "employer"
    },
    "business_operation_need": {
        "name": "经营需要裁员",
        "description": "因用人单位生产经营需要进行的合理裁员",
        "typical_sources": ["财务报告", "业务调整通知", "裁员方案", "工会意见"],
        "supports": "employer"
    },
    "legal_procedure_compliance": {
        "name": "程序合规性",
        "description": "用人单位是否履行了法定的解除劳动合同程序（如通知工会等）",
        "typical_sources": ["工会意见", "通知函", "会议记录", "内部流程文档"],
        "supports": "both"  # 可支持双方，取决于具体情况
    },
    "negotiated_separation": {
        "name": "协商解除",
        "description": "双方协商一致解除劳动合同的证据",
        "typical_sources": ["解除协议", "补偿协议", "邮件确认", "录音"],
        "supports": "both"
    }
}

"""
法律含义说明：

1. 书面合同条款违反：这是劳动法中最基本的证据类型，合同一旦签订就具有法律效力，
   用人单位单方面违反合同条款是非法解除的常见情形。

2. 口头约定违反：虽然劳动合同法要求合同应为书面形式，但口头约定在某些情况下
   也可以作为证据，特别是在招聘阶段的承诺。

3. 纪律处分滥用：用人单位有用工自主权，但必须在合理范围内行使，过度处罚可能
   构成恶意解雇。

4. 职场骚扰：用人单位有义务提供安全的工作环境，恶意刁难员工可能构成非法解雇。

5. 单方面岗位调整：根据劳动合同法，变更劳动合同需要双方协商一致。

6. 强迫辞职压力：用人单位不得通过胁迫手段迫使员工辞职，这属于变相解雇。

7. 工资扣押或克扣：这是严重违反劳动法的行为，可作为非法解雇的证据。

8. 社保公积金违规：用人单位必须依法为员工缴纳社保公积金。

9. 加班无补偿：长期加班无补偿违反劳动法，员工有权拒绝并可作为维权证据。

10. 严重违纪行为：员工严重违纪是用人单位合法解雇的法定事由之一。

11. 业绩不达标：需要有充分的证据证明员工不能胜任工作，且经过培训或调岗后仍不行。

12. 公司关闭重组：属于经济性裁员范畴，需履行法定程序。

13. 经营需要裁员：需符合法定条件和程序，否则可能构成非法解雇。

14. 程序合规性：即使实体上合法，程序不合规也可能导致解雇无效。

15. 协商解除：双方协商一致是合法解除劳动合同的方式之一。
"""