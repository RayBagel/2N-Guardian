"""
证据状态容器模块

定义 EvidenceState 类，用于存储和跟踪证据的存在状态。
每个证据字段可以是 None（未知）、True（存在）或 False（不存在）。
"""

from dataclasses import dataclass
from typing import Optional
from enum import Enum


class EvidenceSupport(Enum):
    """证据支持方向枚举"""
    EMPLOYEE = "employee"      # 支持员工
    EMPLOYER = "employer"      # 支持用人单位
    BOTH = "both"              # 支持双方
    UNKNOWN = "unknown"        # 未知


@dataclass
class EvidenceState:
    """
    证据状态容器类
    存储每种证据类型的存在状态（None=未知, True=存在, False=不存在）
    """
    # 书面合同条款违反
    written_contract_violation: Optional[bool] = None
    
    # 口头约定违反
    verbal_agreement_breach: Optional[bool] = None
    
    # 纪律处分滥用
    discipline_policy_abuse: Optional[bool] = None
    
    # 职场骚扰或恶意刁难
    workplace_harassment: Optional[bool] = None
    
    # 单方面岗位调整
    unilateral_job_change: Optional[bool] = None
    
    # 强迫辞职压力
    forced_resignation_pressure: Optional[bool] = None
    
    # 工资扣押或克扣
    salary_withholding: Optional[bool] = None
    
    # 社保公积金违规
    social_insurance_violation: Optional[bool] = None
    
    # 加班无补偿
    overtime_without_compensation: Optional[bool] = None
    
    # 严重违纪行为
    severe_disciplinary_action: Optional[bool] = None
    
    # 业绩不达标
    performance_deficiency: Optional[bool] = None
    
    # 公司关闭或重组
    company_closure_restructuring: Optional[bool] = None
    
    # 经营需要裁员
    business_operation_need: Optional[bool] = None
    
    # 程序合规性
    legal_procedure_compliance: Optional[bool] = None
    
    # 协商解除
    negotiated_separation: Optional[bool] = None

    def summarize(self) -> dict:
        """
        汇总当前证据状态，用于调试
        返回包含所有证据状态的字典
        """
        return {
            "written_contract_violation": self.written_contract_violation,
            "verbal_agreement_breach": self.verbal_agreement_breach,
            "discipline_policy_abuse": self.discipline_policy_abuse,
            "workplace_harassment": self.workplace_harassment,
            "unilateral_job_change": self.unilateral_job_change,
            "forced_resignation_pressure": self.forced_resignation_pressure,
            "salary_withholding": self.salary_withholding,
            "social_insurance_violation": self.social_insurance_violation,
            "overtime_without_compensation": self.overtime_without_compensation,
            "severe_disciplinary_action": self.severe_disciplinary_action,
            "performance_deficiency": self.performance_deficiency,
            "company_closure_restructuring": self.company_closure_restructuring,
            "business_operation_need": self.business_operation_need,
            "legal_procedure_compliance": self.legal_procedure_compliance,
            "negotiated_separation": self.negotiated_separation
        }

    def count_known_evidence(self) -> int:
        """
        计算已知状态的证据数量
        """
        known_count = 0
        for value in self.summarize().values():
            if value is not None:
                known_count += 1
        return known_count

    def get_support_direction(self, evidence_type: str) -> Optional[EvidenceSupport]:
        """
        获取特定证据类型的支持方向
        """
        schema_mapping = {
            "written_contract_violation": EvidenceSupport.EMPLOYEE,
            "verbal_agreement_breach": EvidenceSupport.EMPLOYEE,
            "discipline_policy_abuse": EvidenceSupport.EMPLOYEE,
            "workplace_harassment": EvidenceSupport.EMPLOYEE,
            "unilateral_job_change": EvidenceSupport.EMPLOYEE,
            "forced_resignation_pressure": EvidenceSupport.EMPLOYEE,
            "salary_withholding": EvidenceSupport.EMPLOYEE,
            "social_insurance_violation": EvidenceSupport.EMPLOYEE,
            "overtime_without_compensation": EvidenceSupport.EMPLOYEE,
            "severe_disciplinary_action": EvidenceSupport.EMPLOYER,
            "performance_deficiency": EvidenceSupport.EMPLOYER,
            "company_closure_restructuring": EvidenceSupport.EMPLOYER,
            "business_operation_need": EvidenceSupport.EMPLOYER,
            "legal_procedure_compliance": EvidenceSupport.BOTH,
            "negotiated_separation": EvidenceSupport.BOTH
        }
        
        support_str = schema_mapping.get(evidence_type, EvidenceSupport.UNKNOWN)
        if support_str:
            return EvidenceSupport(support_str)
        return EvidenceSupport.UNKNOWN