"""
证据追踪器模块

负责分析对话回合并更新证据状态。
该模块仅提取信息，不进行法律判断。
"""

import json
import logging
import re
import os
import hashlib
from typing import Dict, Any, Optional, Tuple
from openai import OpenAI
from .evidence_state import EvidenceState
from .evidence_schema import EVIDENCE_SCHEMA


# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class EvidenceTracker:
    """
    证据追踪器类
    分析对话回合并更新证据状态
    """
    
    def __init__(self):
        # 定义证据关键词映射，用于初步匹配
        self.evidence_keywords = {}
        for evidence_key, evidence_info in EVIDENCE_SCHEMA.items():
            self.evidence_keywords[evidence_key] = {
                'name': evidence_info['name'],
                'description': evidence_info['description'],
                'sources': evidence_info['typical_sources']
            }

        # 证据级关键词：避免“提及劳动争议通用词”导致全量命中
        self.evidence_patterns = {
            "written_contract_violation": ["单方变更", "变更劳动合同", "未经协商变更", "合同条款违反", "违反劳动合同约定", "未提前书面通知"],
            "verbal_agreement_breach": ["口头承诺", "口头约定", "招聘承诺", "承诺未兑现"],
            "discipline_policy_abuse": ["处罚过重", "处分不当", "比例原则", "纪律处分滥用"],
            "workplace_harassment": ["辱骂", "骚扰", "恶意刁难", "侮辱", "逼迫"],
            "unilateral_job_change": ["单方面调岗", "调岗", "岗位调整", "工作地点调整"],
            "forced_resignation_pressure": ["强迫辞职", "逼迫离职", "劝退", "施压离职"],
            "salary_withholding": ["拖欠工资", "克扣工资", "扣薪", "工资未发"],
            "social_insurance_violation": ["未缴社保", "社保断缴", "公积金未缴", "社保违规"],
            "overtime_without_compensation": ["加班无补偿", "未支付加班费", "超时工作未补偿"],
            "severe_disciplinary_action": ["严重违纪", "重大过错", "严重违反规章制度"],
            "performance_deficiency": ["不能胜任", "绩效不达标", "考核不合格"],
            "company_closure_restructuring": ["公司关闭", "经营困难裁员", "重组裁撤"],
            "business_operation_need": ["生产经营需要", "业务调整裁员", "经济性裁员"],
            "legal_procedure_compliance": ["通知工会", "履行法定程序", "程序合法", "程序合规", "未通知工会", "程序违法", "未履行法定程序"],
            "negotiated_separation": ["协商一致解除", "协商解除", "解除协议", "双方同意解除"],
        }

        self.positive_indicators = ["认定", "确认", "查明", "证明", "成立", "属实", "支持", "合法", "违法", "存在", "构成", "显示", "明确"]
        self.negative_indicators = ["未提交", "不足以证明", "无法采信", "不予采信", "不成立", "未能证明", "驳回", "否认", "不存在"]
        self.rule_weight = 0.3
        self.semantic_weight = 0.7
        self.semantic_threshold_medium = 0.58
        self.semantic_threshold_high = 0.75
        self.semantic_model = os.getenv("SEMANTIC_JUDGE_MODEL", "deepseek-ai/DeepSeek-V3")
        self.semantic_client = self._build_semantic_client()
        self._semantic_cache: Dict[str, Dict[str, Dict[str, float]]] = {}
    
    def update(self, evidence_state: EvidenceState, dialogue_turn: Dict[str, str]) -> EvidenceState:
        """
        更新证据状态
        
        Args:
            evidence_state: 当前证据状态
            dialogue_turn: 对话回合，包含system, user, assistant键
            
        Returns:
            更新后的证据状态
        """
        logger.info("开始处理对话回合，更新证据状态")
        
        # 合并对话回合的所有文本内容
        combined_text = self._combine_dialogue_turn(dialogue_turn)
        focused_text, has_court_section = self._extract_court_opinion_scope(combined_text)
        semantic_map = self._semantic_extract(combined_text)
        
        # 创建新的证据状态副本
        new_evidence_state = self._copy_evidence_state(evidence_state)
        
        # 分析文本并更新证据状态
        updated_fields = self._extract_and_update_evidence(
            new_evidence_state,
            focused_text,
            combined_text,
            has_court_section,
            semantic_map,
        )
        
        if updated_fields:
            logger.info(f"更新了以下证据字段: {updated_fields}")
        else:
            logger.info("未检测到新的证据信息")
        
        return new_evidence_state
    
    def _combine_dialogue_turn(self, dialogue_turn: Dict[str, str]) -> str:
        """
        合并对话回合的文本内容
        """
        combined = ""
        for key, value in dialogue_turn.items():
            if isinstance(value, str):
                combined += f"[{key.upper()}] {value}\n"
        return combined
    
    def _copy_evidence_state(self, evidence_state: EvidenceState) -> EvidenceState:
        """
        复制证据状态
        """
        # 使用dataclass的属性动态创建新的实例
        import dataclasses
        copied = dataclasses.replace(evidence_state)
        # 同步复制置信度映射
        existing_conf = getattr(evidence_state, "_evidence_confidence", {})
        setattr(copied, "_evidence_confidence", dict(existing_conf))
        return copied
    
    def _extract_and_update_evidence(
        self,
        evidence_state: EvidenceState,
        strict_text: str,
        full_text: str,
        has_court_section: bool,
        semantic_map: Dict[str, Dict[str, float]],
    ) -> list:
        """
        提取证据并更新状态
        """
        updated_fields = []
        
        # 对每种证据类型进行分析
        for evidence_key in EVIDENCE_SCHEMA.keys():
            try:
                # 通道A：规则兜底（rule channel）
                evidence_detected, confidence = self._check_evidence_mentioned(
                    strict_text,
                    evidence_key,
                    has_court_section
                )
                rule_score = self._rule_score(evidence_detected, confidence, full_text, evidence_key)

                # 通道B：语义判定（semantic channel）
                semantic_info = semantic_map.get(evidence_key, {})
                semantic_found = bool(semantic_info.get("evidence_found", False))
                semantic_conf = float(semantic_info.get("confidence", 0.0))
                semantic_relevance = float(semantic_info.get("legal_relevance", 0.0))
                semantic_score = max(0.0, min(1.0, semantic_conf * semantic_relevance if semantic_found else 0.0))

                # 双通道融合：30%规则 + 70%语义
                blended_score = self.rule_weight * rule_score + self.semantic_weight * semantic_score

                # 记录调试详情
                semantic_detail_map = getattr(evidence_state, "_semantic_evidence_details", {})
                semantic_detail_map[evidence_key] = {
                    "rule_score": rule_score,
                    "semantic_score": semantic_score,
                    "blended_score": blended_score,
                    "semantic_found": semantic_found,
                    "semantic_confidence": semantic_conf,
                    "semantic_legal_relevance": semantic_relevance,
                }
                setattr(evidence_state, "_semantic_evidence_details", semantic_detail_map)

                # 基于融合分数做连续判定
                if blended_score >= self.semantic_threshold_high:
                    blended_detected = True
                    blended_confidence = "high"
                elif blended_score >= self.semantic_threshold_medium:
                    blended_detected = True
                    blended_confidence = "medium"
                elif semantic_found is False and semantic_conf >= 0.75 and semantic_relevance >= 0.7:
                    blended_detected = False
                    blended_confidence = "high"
                else:
                    blended_detected = None
                    blended_confidence = "low"

                # high 直接更新状态
                if blended_detected is not None and blended_confidence == "high":
                    self._update_evidence_value(
                        evidence_state,
                        evidence_key,
                        blended_detected,
                        blended_confidence,
                        updated_fields
                    )
                    continue

                # 记录 medium 正向观察，供 reward 层分层放行
                if blended_detected is True and blended_confidence == "medium":
                    self._record_confidence_observation(evidence_state, evidence_key, "medium")

                # fallback_extraction:
                # 严格模式未提取到时，允许全文的 medium 提取（仅正向、且无否定）
                if blended_detected is None:
                    fallback_detected, fallback_conf = self._check_evidence_fallback(full_text, evidence_key)
                    if fallback_detected is True and fallback_conf == "medium":
                        # fallback 仅记录 medium 观察，不直接写入主状态，避免污染败诉样本推理
                        self._record_confidence_observation(evidence_state, evidence_key, "medium")
                
            except Exception as e:
                logger.error(f"处理证据类型 '{evidence_key}' 时出错: {str(e)}")
        
        return updated_fields

    def _build_semantic_client(self) -> Optional[OpenAI]:
        api_key = os.getenv("SILICONFLOW_API_KEY") or os.getenv("OPENAI_API_KEY")
        if not api_key:
            return None
        try:
            return OpenAI(base_url="https://api.siliconflow.cn/v1", api_key=api_key)
        except Exception:
            return None

    def _semantic_extract(self, text: str) -> Dict[str, Dict[str, float]]:
        """
        通道B：语义概率提取。
        输出结构：
        {
          evidence_key: {
             "evidence_found": bool,
             "confidence": float(0-1),
             "legal_relevance": float(0-1)
          }
        }
        """
        text_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        if text_hash in self._semantic_cache:
            return self._semantic_cache[text_hash]

        # 无可用客户端时，降级为空语义通道
        if self.semantic_client is None:
            self._semantic_cache[text_hash] = {}
            return {}

        schema_keys = list(EVIDENCE_SCHEMA.keys())
        prompt = (
            "你是法律证据抽取评估器。请阅读文本并仅输出 JSON。\n"
            "对每个 evidence key 给出:\n"
            "- evidence_found: true/false\n"
            "- confidence: 0.0-1.0\n"
            "- legal_relevance: 0.0-1.0\n\n"
            f"evidence keys: {schema_keys}\n\n"
            "输出格式:\n"
            "{\n"
            '  "written_contract_violation": {"evidence_found": false, "confidence": 0.0, "legal_relevance": 0.0},\n'
            '  "...": {"evidence_found": true, "confidence": 0.8, "legal_relevance": 0.9}\n'
            "}\n\n"
            f"文本:\n{text}"
        )

        try:
            resp = self.semantic_client.chat.completions.create(
                model=self.semantic_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=1800,
            )
            content = resp.choices[0].message.content or "{}"
            start = content.find("{")
            end = content.rfind("}") + 1
            payload = content[start:end] if start != -1 and end > start else "{}"
            parsed = json.loads(payload)
            normalized: Dict[str, Dict[str, float]] = {}
            for key in schema_keys:
                item = parsed.get(key, {})
                normalized[key] = {
                    "evidence_found": bool(item.get("evidence_found", False)),
                    "confidence": float(max(0.0, min(1.0, float(item.get("confidence", 0.0))))),
                    "legal_relevance": float(max(0.0, min(1.0, float(item.get("legal_relevance", 0.0))))),
                }
            self._semantic_cache[text_hash] = normalized
            return normalized
        except Exception as e:
            logger.debug(f"语义抽取失败，降级规则模式: {e}")
            self._semantic_cache[text_hash] = {}
            return {}

    def _rule_score(
        self,
        evidence_detected: Optional[bool],
        confidence: str,
        full_text: str,
        evidence_key: str
    ) -> float:
        base = 0.0
        if evidence_detected is True:
            base = 1.0 if confidence == "high" else 0.6 if confidence == "medium" else 0.3
        elif evidence_detected is False:
            base = 0.2 if confidence == "high" else 0.1
        else:
            # fallback medium positive contributes weakly
            fallback_detected, fallback_conf = self._check_evidence_fallback(full_text, evidence_key)
            if fallback_detected is True and fallback_conf == "medium":
                base = 0.55
        return max(0.0, min(1.0, base))

    def _update_evidence_value(
        self,
        evidence_state: EvidenceState,
        evidence_key: str,
        evidence_detected: bool,
        confidence: str,
        updated_fields: list
    ) -> None:
        """
        更新证据值并记录置信度。
        """
        current_value = getattr(evidence_state, evidence_key)
        confidence_map = getattr(evidence_state, "_evidence_confidence", {})

        if current_value is None:
            setattr(evidence_state, evidence_key, evidence_detected)
            confidence_map[evidence_key] = confidence
            setattr(evidence_state, "_evidence_confidence", confidence_map)
            updated_fields.append(evidence_key)
            logger.debug(
                f"更新证据 '{evidence_key}' 为 {evidence_detected}，confidence={confidence}"
            )
        elif current_value != evidence_detected:
            logger.debug(
                f"检测到证据 '{evidence_key}' 冲突，现有={current_value}, 新检测={evidence_detected}, confidence={confidence}"
            )

    def _record_confidence_observation(
        self,
        evidence_state: EvidenceState,
        evidence_key: str,
        confidence: str
    ) -> None:
        """
        记录证据观察置信度，不修改主状态值。
        """
        confidence_map = getattr(evidence_state, "_evidence_confidence", {})
        existing = confidence_map.get(evidence_key)
        if existing == "high":
            return
        confidence_map[evidence_key] = confidence
        setattr(evidence_state, "_evidence_confidence", confidence_map)
    
    def _extract_court_opinion_scope(self, text: str) -> Tuple[str, bool]:
        """
        Scope Refinement:
        优先提取“法院认定/本院认为”范围，降低当事人主张噪声。
        """
        lower_text = text.lower()
        markers = ["本院认为", "法院认为", "经审理查明", "裁判结果", "判决如下", "法院查明"]
        positions = [lower_text.find(m.lower()) for m in markers if lower_text.find(m.lower()) != -1]
        if positions:
            start = min(positions)
            return text[start:], True
        return text, False

    def _has_negative_context(self, text: str, keyword: str, window: int = 24) -> bool:
        """
        Logic Inversion Check:
        若关键词邻域内出现否定词，按 False 处理。
        """
        for match in re.finditer(re.escape(keyword), text):
            left = max(0, match.start() - window)
            right = min(len(text), match.end() + window)
            context = text[left:right]
            if any(neg in context for neg in self.negative_indicators):
                return True
        return False

    def _check_evidence_mentioned(self, text: str, evidence_key: str, has_court_section: bool) -> Tuple[Optional[bool], str]:
        """
        检查文本是否提及特定证据类型
        返回 (证据值, 置信度)
        """
        evidence_info = self.evidence_keywords[evidence_key]
        pattern_candidates = self.evidence_patterns.get(evidence_key, [])
        pattern_candidates += [
            evidence_info["name"],
            evidence_info["description"],
            *evidence_info["sources"],
        ]

        matched_keywords = [kw for kw in pattern_candidates if kw and kw in text]
        if not matched_keywords:
            return None, "low"

        has_positive = any(pos in text for pos in self.positive_indicators)
        has_negative = False
        for kw in matched_keywords:
            if self._has_negative_context(text, kw):
                has_negative = True
                break
        if not has_negative:
            has_negative = any(neg in text for neg in self.negative_indicators)

        # 否定优先
        if has_negative:
            confidence = "high" if has_court_section else "medium"
            return False, confidence

        # 仅当在法院认定范围内 + 存在肯定信号时，给高置信度 True
        if has_court_section and has_positive:
            return True, "high"

        # 没有法院认定范围时，最多中置信度，不参与状态更新
        if has_positive:
            return True, "medium"

        return None, "low"

    def _check_evidence_fallback(self, text: str, evidence_key: str) -> Tuple[Optional[bool], str]:
        """
        fallback_extraction:
        全文范围内提取 medium 证据，要求：
        1) 命中证据关键词
        2) 存在正向信号
        3) 不存在否定上下文
        """
        pattern_candidates = self.evidence_patterns.get(evidence_key, [])
        matched_keywords = [kw for kw in pattern_candidates if kw and kw in text]
        if not matched_keywords:
            return None, "low"

        has_positive = any(pos in text for pos in self.positive_indicators)
        if not has_positive:
            return None, "low"

        for kw in matched_keywords:
            if self._has_negative_context(text, kw):
                return False, "medium"

        if any(neg in text for neg in self.negative_indicators):
            return None, "low"

        return True, "medium"


# 示例使用函数
def demo_evidence_tracking():
    """
    演示证据追踪功能
    """
    tracker = EvidenceTracker()
    initial_state = EvidenceState()
    
    # 示例对话回合
    dialogue_turn = {
        "system": "你是一个法律博弈专家。基于这个真实的胜诉案例，重现员工的高明操作。",
        "user": "这是HR的真实施压话术，请生成员工的高明应对策略：公司单方面变更劳动合同内容",
        "assistant": "面对HR的单方面变更合同内容，员工应明确表达这违反了劳动合同法第三十五条..."
    }
    
    updated_state = tracker.update(initial_state, dialogue_turn)
    summary = updated_state.summarize()
    
    print("证据状态摘要:")
    for key, value in summary.items():
        if value is not None:
            print(f"  {key}: {value}")
    
    print(f"\n已知证据数量: {updated_state.count_known_evidence()}")
