"""
StepWiseRewardEngine 模块

分步骤评估司法推理质量的奖励引擎。
将司法三段论评估结果转换为标量奖励值。
实现基于结构化评估的可解释奖励机制。
"""

import numpy as np
import re
from enum import Enum
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass
# 为直接运行时的相对导入问题提供兼容性
try:
    from ..legal_reasoning.syllogism_evaluator import ReasoningTrace, VerdictTendency
except ImportError:
    # 定义模拟类用于演示
    from enum import Enum
    from dataclasses import dataclass
    from typing import List
    
    class VerdictTendency(Enum):
        WIN = "win"
        LOSE = "lose"
        UNCERTAIN = "uncertain"
    
    @dataclass
    class ReasoningTrace:
        verdict: VerdictTendency
        missing_elements: List[str]
        reasoning_explanation: str
        supporting_factors: List[str]
        opposing_factors: List[str]


class RewardType(Enum):
    """奖励类型枚举"""
    STRONG_NEGATIVE = "strong_negative"  # 强负奖励
    MILD_NEGATIVE = "mild_negative"      # 轻微负奖励
    NEUTRAL = "neutral"                  # 中性奖励
    POSITIVE = "positive"                # 正奖励
    STRONG_POSITIVE = "strong_positive"  # 强正奖励


@dataclass
class EvaluationStep:
    """评估步骤结果"""
    name: str
    score: float  # 0-1范围
    explanation: str


@dataclass
class RewardBreakdown:
    """奖励分解类"""
    total_reward: float
    steps: List[EvaluationStep]
    reasoning_trace: str
    supporting_factors: List[str]
    opposing_factors: List[str]
    reward_type: RewardType
    explanation: str
    # 司法结构相关字段
    elements_satisfied: List[str]
    supporting_evidence: List[str]
    missing_elements: List[str]
    # 可解释化增强字段
    debug_info: Optional[Dict[str, Any]] = None


@dataclass
class DebugRewardBreakdown:
    """调试模式下的奖励分解结构"""
    total_reward: float
    steps: Dict[str, float]  # premise, evidence, rule_mapping, conclusion
    penalties: Dict[str, float]  # missing_element_penalty, contradiction_penalty
    explanations: Dict[str, str]  # 各步骤的详细解释


class StepWiseRewardEngine:
    """
    分步骤奖励引擎
    实现结构化的司法推理质量评估
    """
    
    def __init__(self):
        # 权重配置
        self.weights = {
            'structure': 0.3,
            'coverage': 0.3,
            'evidence': 0.2,
            'strategy': 0.2
        }
        
        # 门控阈值
        self.gating_threshold = 0.75
    
    def evaluate(self, reasoning_trace: ReasoningTrace, judicial_analysis: Dict[str, Any] = None, 
                debug: bool = False) -> RewardBreakdown:
        """
        分步骤评估司法推理质量
        
        Args:
            reasoning_trace: 推理轨迹
            judicial_analysis: 司法分析结果
            debug: 是否返回调试信息
            
        Returns:
            RewardBreakdown: 奖励分解
        """
        # 执行四个评估步骤
        structure_step = self.evaluate_structure(reasoning_trace, judicial_analysis)
        coverage_step = self.evaluate_coverage(reasoning_trace, judicial_analysis)
        evidence_step = self.evaluate_evidence(reasoning_trace, judicial_analysis)
        strategy_step = self.evaluate_strategy(reasoning_trace, judicial_analysis)
        
        steps = [structure_step, coverage_step, evidence_step, strategy_step]
        
        # 门控逻辑：如果结构评分 < 0.75，返回-0.5
        if structure_step.score < self.gating_threshold:
            total_reward = -0.5
            reward_type = RewardType.MILD_NEGATIVE
            explanation = f"结构评分过低 ({structure_step.score:.2f} < {self.gating_threshold})，触发门控机制"
        else:
            # 加权求和计算总奖励
            total_reward = (
                structure_step.score * self.weights['structure'] +
                coverage_step.score * self.weights['coverage'] +
                evidence_step.score * self.weights['evidence'] +
                strategy_step.score * self.weights['strategy']
            )
            
            # 转换到[-1, 1]范围
            total_reward = total_reward * 2 - 1
            reward_type = self._determine_reward_type(total_reward)
            explanation = self._generate_overall_explanation(steps, total_reward)
        
        # 提取司法结构信息
        elements_satisfied = judicial_analysis.get('elements_satisfied', []) if judicial_analysis else []
        supporting_evidence = judicial_analysis.get('supporting_evidence', []) if judicial_analysis else []
        missing_elements = reasoning_trace.missing_elements if reasoning_trace else []
        
        # 构建基础奖励分解
        reward_breakdown = RewardBreakdown(
            total_reward=total_reward,
            steps=steps,
            reasoning_trace=reasoning_trace.reasoning_explanation if reasoning_trace else "",
            supporting_factors=reasoning_trace.supporting_factors if reasoning_trace else [],
            opposing_factors=reasoning_trace.opposing_factors if reasoning_trace else [],
            reward_type=reward_type,
            explanation=explanation,
            elements_satisfied=elements_satisfied,
            supporting_evidence=supporting_evidence,
            missing_elements=missing_elements
        )
        
        # 如果启用调试模式，添加详细分解信息
        if debug:
            debug_info = self._generate_debug_info(
                structure_step, coverage_step, evidence_step, strategy_step,
                reasoning_trace, judicial_analysis
            )
            reward_breakdown.debug_info = debug_info
            
        return reward_breakdown
    
    def _generate_debug_info(self, structure_step: EvaluationStep, coverage_step: EvaluationStep,
                           evidence_step: EvaluationStep, strategy_step: EvaluationStep,
                           reasoning_trace: ReasoningTrace, judicial_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """
        生成调试模式下的详细奖励分解信息
        
        将原有的四个评估步骤映射到新的step-wise结构：
        - premise: 基于structure_step
        - evidence: 基于evidence_step  
        - rule_mapping: 基于coverage_step
        - conclusion: 基于strategy_step
        """
        # 计算惩罚项
        missing_penalty = self._calculate_missing_element_penalty(reasoning_trace)
        contradiction_penalty = self._calculate_contradiction_penalty(judicial_analysis)
        
        # 将原有步骤映射到新的step-wise结构
        step_rewards = {
            "premise": structure_step.score,
            "evidence": evidence_step.score,
            "rule_mapping": coverage_step.score,
            "conclusion": strategy_step.score
        }
        
        penalties = {
            "missing_element_penalty": missing_penalty,
            "contradiction_penalty": contradiction_penalty
        }
        
        # 各步骤的详细解释
        explanations = {
            "premise": structure_step.explanation,
            "evidence": evidence_step.explanation,
            "rule_mapping": coverage_step.explanation,
            "conclusion": strategy_step.explanation,
            "missing_penalty": f"缺失要素数量: {len(reasoning_trace.missing_elements) if reasoning_trace else 0}",
            "contradiction_penalty": f"证据矛盾检测: {'发现矛盾' if contradiction_penalty < 0 else '无矛盾'}"
        }
        
        return {
            "total_reward": self._calculate_debug_total_reward(step_rewards, penalties),
            "steps": step_rewards,
            "penalties": penalties,
            "explanations": explanations
        }
    
    def _calculate_debug_total_reward(self, step_rewards: Dict[str, float], 
                                    penalties: Dict[str, float]) -> float:
        """计算调试模式下的总奖励"""
        # 基础步骤奖励加权求和
        base_reward = (
            step_rewards["premise"] * 0.25 +
            step_rewards["evidence"] * 0.25 +
            step_rewards["rule_mapping"] * 0.25 +
            step_rewards["conclusion"] * 0.25
        )
        
        # 应用惩罚
        total_penalty = sum(penalties.values())
        
        # 转换到[-1, 1]范围
        total_reward = base_reward + total_penalty
        return max(-1.0, min(1.0, total_reward))
    
    def _calculate_missing_element_penalty(self, reasoning_trace: ReasoningTrace) -> float:
        """计算缺失要素惩罚"""
        if not reasoning_trace:
            return -0.3
        
        missing_count = len(reasoning_trace.missing_elements)
        if missing_count == 0:
            return 0.0
        elif missing_count == 1:
            return -0.1
        elif missing_count == 2:
            return -0.2
        else:
            return -0.3
    
    def _calculate_contradiction_penalty(self, judicial_analysis: Dict[str, Any]) -> float:
        """计算证据矛盾惩罚"""
        if not judicial_analysis:
            return 0.0
            
        # 简单的矛盾检测逻辑
        elements_satisfied = judicial_analysis.get('elements_satisfied', [])
        supporting_evidence = judicial_analysis.get('supporting_evidence', [])
        
        # 如果满足的要素很少但证据很多，可能存在矛盾
        if len(elements_satisfied) <= 1 and len(supporting_evidence) >= 3:
            return -0.2
        return 0.0
    
    def evaluate_structure(self, reasoning_trace: ReasoningTrace, judicial_analysis: Dict[str, Any]) -> EvaluationStep:
        """
        评估推理结构质量
        
        Args:
            reasoning_trace: 推理轨迹
            judicial_analysis: 司法分析结果
            
        Returns:
            EvaluationStep: 结构评估结果
        """
        if not reasoning_trace:
            return EvaluationStep("structure", 0.0, "缺少推理轨迹")
        
        # 检查基本结构完整性
        has_reasoning = bool(reasoning_trace.reasoning_explanation)
        has_factors = (len(reasoning_trace.supporting_factors) > 0 or 
                      len(reasoning_trace.opposing_factors) > 0)
        
        # 基于判决倾向的结构质量评估
        if reasoning_trace.verdict == VerdictTendency.WIN:
            base_score = 0.8
        elif reasoning_trace.verdict == VerdictTendency.LOSE:
            base_score = 0.7
        else:  # UNCERTAIN
            base_score = 0.5
        
        # 结构完整性加成
        completeness_bonus = 0.0
        if has_reasoning:
            completeness_bonus += 0.1
        if has_factors:
            completeness_bonus += 0.1
            
        final_score = min(1.0, base_score + completeness_bonus)
        
        explanation = f"判决倾向: {reasoning_trace.verdict.value}, 结构完整性: {final_score:.2f}"
        if has_reasoning:
            explanation += " (含推理说明)"
        if has_factors:
            explanation += " (含支持/反对因素)"
            
        return EvaluationStep("structure", final_score, explanation)
    
    def evaluate_coverage(self, reasoning_trace: ReasoningTrace, judicial_analysis: Dict[str, Any]) -> EvaluationStep:
        """
        评估法律要素覆盖度
        
        Args:
            reasoning_trace: 推理轨迹
            judicial_analysis: 司法分析结果
            
        Returns:
            EvaluationStep: 覆盖度评估结果
        """
        if not judicial_analysis:
            return EvaluationStep("coverage", 0.0, "缺少司法分析数据")
        
        elements_satisfied = judicial_analysis.get('elements_satisfied', [])
        missing_elements = reasoning_trace.missing_elements if reasoning_trace else []
        
        total_elements = len(elements_satisfied) + len(missing_elements)
        if total_elements == 0:
            return EvaluationStep("coverage", 0.0, "未识别任何法律要素")
        
        coverage_ratio = len(elements_satisfied) / total_elements
        final_score = coverage_ratio
        
        explanation = f"满足要素: {len(elements_satisfied)}/{total_elements} ({coverage_ratio:.2f})"
        if missing_elements:
            explanation += f", 缺失要素: {missing_elements}"
            
        return EvaluationStep("coverage", final_score, explanation)
    
    def evaluate_evidence(self, reasoning_trace: ReasoningTrace, judicial_analysis: Dict[str, Any]) -> EvaluationStep:
        """
        评估证据支撑质量
        
        Args:
            reasoning_trace: 推理轨迹
            judicial_analysis: 司法分析结果
            
        Returns:
            EvaluationStep: 证据评估结果
        """
        if not judicial_analysis:
            return EvaluationStep("evidence", 0.0, "缺少司法分析数据")
        
        supporting_evidence = judicial_analysis.get('supporting_evidence', [])
        evidence_count = len(supporting_evidence)
        
        # 基于证据数量的评分（最多5个证据）
        max_evidence = 5
        evidence_ratio = min(1.0, evidence_count / max_evidence)
        
        # 证据质量调整
        quality_bonus = 0.0
        if evidence_count >= 3:
            quality_bonus = 0.1  # 证据充分
        elif evidence_count >= 1:
            quality_bonus = 0.05  # 有基本证据
            
        final_score = min(1.0, evidence_ratio + quality_bonus)
        
        explanation = f"支持证据: {evidence_count}个"
        if evidence_count > 0:
            explanation += f" ({supporting_evidence[:3]}{'...' if len(supporting_evidence) > 3 else ''})"
        if quality_bonus > 0:
            explanation += f" (质量加成: +{quality_bonus:.2f})"
            
        return EvaluationStep("evidence", final_score, explanation)
    
    def evaluate_strategy(self, reasoning_trace: ReasoningTrace, judicial_analysis: Dict[str, Any]) -> EvaluationStep:
        """
        评估推理策略质量
        
        Args:
            reasoning_trace: 推理轨迹
            judicial_analysis: 司法分析结果
            
        Returns:
            EvaluationStep: 策略评估结果
        """
        if not reasoning_trace:
            return EvaluationStep("strategy", 0.0, "缺少推理轨迹")
        
        # 检查自毁行为指标
        self_harm_indicators = ['自认违纪', '放弃抗辩', '承认过错', '主动辞职']
        reasoning_text = reasoning_trace.reasoning_explanation if reasoning_trace else ""
        
        has_self_harm = any(indicator in reasoning_text for indicator in self_harm_indicators)
        
        # 基于判决倾向的策略质量
        if reasoning_trace.verdict == VerdictTendency.WIN:
            if has_self_harm:
                base_score = 0.4  # WIN但有自毁行为
                explanation = "WIN判决但存在自毁行为"
            else:
                base_score = 0.9  # WIN且无自毁行为
                explanation = "WIN判决且策略合理"
        elif reasoning_trace.verdict == VerdictTendency.LOSE:
            if has_self_harm:
                base_score = 0.2  # LOSE且有自毁行为
                explanation = "LOSE判决且存在自毁行为"
            else:
                base_score = 0.6  # LOSE但策略合理
                explanation = "LOSE判决但策略相对合理"
        else:  # UNCERTAIN
            base_score = 0.5
            explanation = "判决不确定"
        
        return EvaluationStep("strategy", base_score, explanation)
    
    def _determine_reward_type(self, total_reward: float) -> RewardType:
        """
        根据总奖励值确定奖励类型
        
        Args:
            total_reward: 总奖励值 [-1, 1]
            
        Returns:
            RewardType: 奖励类型
        """
        if total_reward >= 0.5:
            return RewardType.STRONG_POSITIVE
        elif total_reward >= 0.1:
            return RewardType.POSITIVE
        elif total_reward >= -0.1:
            return RewardType.NEUTRAL
        elif total_reward >= -0.5:
            return RewardType.MILD_NEGATIVE
        else:
            return RewardType.STRONG_NEGATIVE
    
    def _generate_overall_explanation(self, steps: List[EvaluationStep], total_reward: float) -> str:
        """
        生成总体解释
        
        Args:
            steps: 评估步骤列表
            total_reward: 总奖励值
            
        Returns:
            解释文本
        """
        explanations = [f"{step.name}: {step.score:.2f}" for step in steps]
        weighted_sum = " + ".join([
            f"{step.score:.2f}×{self.weights[step.name]:.1f}" 
            for step in steps
        ])
        
        return f"加权求和: {weighted_sum} = {total_reward:.3f}"


@dataclass
class AdapterRewardBreakdown:
    """兼容旧测试管线的奖励分解结构"""
    total_reward: float
    components: Dict[str, float]
    reasoning_trace: str
    supporting_factors: List[str]
    opposing_factors: List[str]
    reward_type: RewardType
    explanation: str
    elements_satisfied: List[str]
    supporting_evidence: List[str]
    missing_elements: List[str]


class RewardAdapter:
    """
    兼容层：对外保留旧版 RewardAdapter 接口，
    内部委托给 StepWiseRewardEngine。
    """

    def __init__(self):
        self.engine = StepWiseRewardEngine()
        self.logic_chain_blend = 0.2
        self.core_blend = 1.0 - self.logic_chain_blend
        self.fact_weight = 0.4
        self.law_weight = 0.3
        self.process_weight = 0.3

    def _compute_logic_chain_score(
        self,
        reasoning_trace: ReasoningTrace,
        judicial_analysis: Optional[Dict[str, Any]],
    ) -> float:
        """
        连续型逻辑链完整性评分：
        前提事实 -> 法律依据 -> 结论输出
        """
        if reasoning_trace is None:
            return 0.0

        elements = judicial_analysis.get("elements_satisfied", []) if judicial_analysis else []
        evidences = judicial_analysis.get("supporting_evidence", []) if judicial_analysis else []
        reasoning_text = str(getattr(reasoning_trace, "reasoning_explanation", "") or "")

        premise_score = 0.0
        if len(elements) > 0:
            premise_score += 0.6
        if len(evidences) > 0:
            premise_score += 0.4
        premise_score = min(1.0, premise_score)

        rule_keywords = ["劳动合同法", "法条", "第", "条", "依据", "法律", "规定"]
        rule_score = 1.0 if any(kw in reasoning_text for kw in rule_keywords) else 0.0

        conclusion_keywords = ["综上", "因此", "结论", "应当", "故", "判定", "倾向"]
        verdict_value = str(getattr(getattr(reasoning_trace, "verdict", None), "value", "")).strip()
        conclusion_score = 0.5 if verdict_value else 0.0
        if any(kw in reasoning_text for kw in conclusion_keywords):
            conclusion_score = 1.0

        chain_score = 0.4 * premise_score + 0.3 * rule_score + 0.3 * conclusion_score
        return float(max(0.0, min(1.0, chain_score)))

    @staticmethod
    def _chinese_num_to_int(token: str) -> int:
        if not token:
            return 0
        if token.isdigit():
            return int(token)

        digits = {
            "零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
            "五": 5, "六": 6, "七": 7, "八": 8, "九": 9,
        }
        # 支持到百位，覆盖 39/40/47/87 以及常见劳动法条号表达。
        if token == "十":
            return 10
        if "百" in token:
            parts = token.split("百", 1)
            left = digits.get(parts[0], 1) if parts[0] else 1
            rest = parts[1]
            if not rest:
                return left * 100
            if rest.startswith("十"):
                right = 10 + digits.get(rest[1:], 0) if len(rest) > 1 else 10
            else:
                right = digits.get(rest, 0)
            return left * 100 + right
        if "十" in token:
            parts = token.split("十", 1)
            left = digits.get(parts[0], 1) if parts[0] else 1
            right = digits.get(parts[1], 0) if parts[1] else 0
            return left * 10 + right
        return digits.get(token, 0)

    @classmethod
    def _extract_articles(cls, reasoning_text: str) -> List[int]:
        nums = re.findall(r"第\s*(\d{1,3})\s*条", reasoning_text)
        zh_nums = re.findall(r"第\s*([零一二两三四五六七八九十百]{1,6})\s*条", reasoning_text)
        result = {int(x) for x in nums}
        for token in zh_nums:
            n = cls._chinese_num_to_int(token)
            if n > 0:
                result.add(n)
        return sorted(result)

    @staticmethod
    def _clip01(value: float) -> float:
        return float(max(0.0, min(1.0, value)))

    def _is_2n_context(self, reasoning_text: str) -> bool:
        tokens = ["2n", "2 n", "二倍", "两倍", "赔偿金", "违法解除"]
        lower_text = reasoning_text.lower()
        return any(tok in lower_text for tok in tokens)

    def statute_context_match(
        self,
        reasoning_text: str,
        judicial_analysis: Optional[Dict[str, Any]],
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Score_Law: 条文精确性 + 2N场景适配性检查。
        """
        assistant_text = ""
        if judicial_analysis:
            assistant_text = str(judicial_analysis.get("assistant_raw_text", "") or "")
        analysis_text = (assistant_text + "\n" + reasoning_text).strip()

        articles = self._extract_articles(analysis_text)
        has_labor_law = ("劳动合同法" in analysis_text) or bool(articles)
        is_2n = self._is_2n_context(analysis_text)

        specificity = 1.0 if articles else (0.35 if has_labor_law else 0.0)
        applicability = 0.0
        mismatch = False

        if is_2n:
            # 2N 场景下，核心条文应为第87条，47条通常是N补偿计算基数。
            if 87 in articles:
                applicability = 1.0
            elif 47 in articles:
                applicability = 0.0
                mismatch = True
            elif has_labor_law:
                applicability = 0.45
            else:
                applicability = 0.0
        else:
            if any(a in articles for a in [39, 40, 41, 46, 47, 87]):
                applicability = 1.0
            elif has_labor_law:
                applicability = 0.5
            else:
                applicability = 0.0

        lower_text = analysis_text.lower()
        confusion_penalty = 0.0
        if ("补偿金" in lower_text) and (87 in articles):
            confusion_penalty += 0.2
            mismatch = True
        if ("赔偿金" in lower_text) and (47 in articles) and (87 not in articles):
            confusion_penalty += 0.35
            mismatch = True

        score = self._clip01(0.45 * specificity + 0.55 * applicability - confusion_penalty)
        detail = {
            "articles": articles,
            "has_labor_law": has_labor_law,
            "is_2n_context": is_2n,
            "mismatch": mismatch,
        }
        return score, detail

    def verify_logic_chain(
        self,
        reasoning_trace: ReasoningTrace,
        judicial_analysis: Optional[Dict[str, Any]],
        law_detail: Dict[str, Any],
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Zero-Tolerance Rule:
        环1 事实->法条；环2 法条->结论。任一断裂则 Score_Process=0。
        """
        if reasoning_trace is None:
            return False, {
                "ring1": False,
                "ring2": False,
                "reason": "missing_reasoning_trace",
                "fact_law_penalty": 0.3,
                "law_conclusion_penalty": 0.5,
                "triggered_penalties": ["ring1", "ring2"],
            }

        reasoning_text = str(getattr(reasoning_trace, "reasoning_explanation", "") or "")
        elements = judicial_analysis.get("elements_satisfied", []) if judicial_analysis else []
        evidences = judicial_analysis.get("supporting_evidence", []) if judicial_analysis else []
        confidence_map = judicial_analysis.get("supporting_evidence_confidence", {}) if judicial_analysis else {}
        high_count = sum(1 for _, conf in confidence_map.items() if str(conf).lower() == "high")

        illegal_fact_tokens = ["lack_of_legal_basis", "procedural_violation", "illegal", "absence_of_statutory_ground"]
        has_illegal_fact = (
            any(tok in str(x).lower() for tok in illegal_fact_tokens for x in elements)
            or any(k in evidences for k in ["forced_resignation_pressure", "written_contract_violation", "unilateral_job_change"])
            or any(tok in reasoning_text for tok in ["违法解除", "程序违法", "未通知工会", "未履行法定程序"])
        )
        has_compliance_signal = any(tok in reasoning_text for tok in ["程序合法", "程序合规", "依法履行程序"])

        # 环1：事实是否足以触发法条
        ring1 = bool(elements or evidences or high_count > 0)
        if law_detail.get("is_2n_context", False):
            ring1 = has_illegal_fact and not (has_compliance_signal and not has_illegal_fact)

        # 环2：法条是否支持结论
        articles = set(law_detail.get("articles", []))
        has_2n_conclusion = any(tok in reasoning_text.lower() for tok in ["2n", "2 n", "二倍", "两倍", "赔偿金"])
        has_n_conclusion = any(tok in reasoning_text.lower() for tok in ["补偿金", "n"])

        if law_detail.get("is_2n_context", False):
            ring2 = (87 in articles or not articles) and has_2n_conclusion and (not law_detail.get("mismatch", False))
        else:
            if (47 in articles) and has_2n_conclusion and (87 not in articles):
                ring2 = False
            elif (87 in articles) and has_n_conclusion and not has_2n_conclusion:
                ring2 = False
            else:
                ring2 = not law_detail.get("mismatch", False)

        fact_law_penalty = 1.0 if ring1 else 0.3
        law_conclusion_penalty = 1.0 if ring2 else 0.5
        triggered_penalties: List[str] = []
        if not ring1:
            triggered_penalties.append("ring1")
        if not ring2:
            triggered_penalties.append("ring2")

        passed = bool(ring1 and ring2)
        return passed, {
            "ring1": ring1,
            "ring2": ring2,
            "fact_law_penalty": fact_law_penalty,
            "law_conclusion_penalty": law_conclusion_penalty,
            "triggered_penalties": triggered_penalties,
        }

    @staticmethod
    def _prm_reward_type(score: float) -> RewardType:
        if score >= 0.8:
            return RewardType.STRONG_POSITIVE
        if score >= 0.6:
            return RewardType.POSITIVE
        if score >= 0.4:
            return RewardType.NEUTRAL
        if score >= 0.2:
            return RewardType.MILD_NEGATIVE
        return RewardType.STRONG_NEGATIVE

    def adapt(
        self,
        reasoning_trace: ReasoningTrace,
        judicial_analysis: Optional[Dict[str, Any]] = None,
    ) -> AdapterRewardBreakdown:
        step_result = self.engine.evaluate(reasoning_trace, judicial_analysis)

        step_scores = {step.name: step.score for step in step_result.steps}
        structure_raw = step_scores.get("structure", 0.0)
        coverage_raw = step_scores.get("coverage", 0.0)
        evidence_raw = step_scores.get("evidence", 0.0)
        strategy_raw = step_scores.get("strategy", 0.0)

        # Outcome-aware confidence acceptance.
        accepted_confidences = {"high"}
        outcome = str(judicial_analysis.get("outcome", "")).lower() if judicial_analysis else ""
        if outcome == "win":
            accepted_confidences = {"high", "medium"}

        confidence_map = {}
        if judicial_analysis:
            confidence_map = judicial_analysis.get("supporting_evidence_confidence", {}) or {}

        accepted_evidence = [
            key for key, conf in confidence_map.items() if str(conf).lower() in accepted_confidences
        ]
        accepted_count = len(accepted_evidence)
        accepted_evidence_ratio = self._clip01(accepted_count / 5.0)
        logic_chain_score = self._compute_logic_chain_score(reasoning_trace, judicial_analysis)
        fact_rule_signal = (
            0.45 * coverage_raw +
            0.45 * evidence_raw +
            0.10 * structure_raw
        )
        # Activate combined_signal as Score_Fact core.
        combined_signal = self.core_blend * fact_rule_signal + self.logic_chain_blend * logic_chain_score
        score_fact = self._clip01(0.75 * combined_signal + 0.25 * accepted_evidence_ratio)

        reasoning_text = str(getattr(reasoning_trace, "reasoning_explanation", "") or "")
        score_law, law_detail = self.statute_context_match(reasoning_text, judicial_analysis)
        process_passed, process_detail = self.verify_logic_chain(reasoning_trace, judicial_analysis, law_detail)
        # Soft Penalty Fallback: base_logic_score * fact_law_penalty * law_conclusion_penalty
        base_logic_score = self._clip01(0.6 + 0.4 * logic_chain_score)
        fact_law_penalty = float(process_detail.get("fact_law_penalty", 1.0))
        law_conclusion_penalty = float(process_detail.get("law_conclusion_penalty", 1.0))
        score_process = self._clip01(base_logic_score * fact_law_penalty * law_conclusion_penalty)

        # PRM-centric 40/30/30 formula.
        total_reward = self._clip01(
            self.fact_weight * score_fact +
            self.law_weight * score_law +
            self.process_weight * score_process
        )
        components = {
            "score_fact": float(score_fact),
            "score_law": float(score_law),
            "score_process": float(score_process),
            "base_logic_score": float(base_logic_score),
            "fact_law_penalty": float(fact_law_penalty),
            "law_conclusion_penalty": float(law_conclusion_penalty),
            "combined_signal": float(combined_signal),
            "logic_chain_score": float(logic_chain_score),
            "process_ring1_pass": float(1.0 if process_detail.get("ring1") else 0.0),
            "process_ring2_pass": float(1.0 if process_detail.get("ring2") else 0.0),
        }
        explanation = (
            f"PRM(40/30/30): fact={score_fact:.3f}, law={score_law:.3f}, process={score_process:.3f}; "
            f"rings=({process_detail.get('ring1')},{process_detail.get('ring2')}), "
            f"penalties=({fact_law_penalty:.2f},{law_conclusion_penalty:.2f}), "
            f"triggered={process_detail.get('triggered_penalties', [])}, "
            f"articles={law_detail.get('articles', [])}, mismatch={law_detail.get('mismatch', False)}"
        )

        return AdapterRewardBreakdown(
            total_reward=total_reward,
            components=components,
            reasoning_trace=step_result.reasoning_trace,
            supporting_factors=step_result.supporting_factors,
            opposing_factors=step_result.opposing_factors,
            reward_type=self._prm_reward_type(total_reward),
            explanation=explanation,
            elements_satisfied=step_result.elements_satisfied,
            supporting_evidence=step_result.supporting_evidence,
            missing_elements=step_result.missing_elements,
        )


# 使用示例
def demo_stepwise_reward():
    """
    演示分步骤奖励评估功能
    """
    engine = StepWiseRewardEngine()
    
    # 模拟不同类型的司法分析结果
    test_cases = [
        {
            "name": "Win_Real案例",
            "verdict": VerdictTendency.WIN,
            "judicial_analysis": {
                "elements_satisfied": ["contract_exists", "termination_occurred", "lack_of_legal_basis"],
                "supporting_evidence": ["written_contract_violation", "legal_procedure_compliance", 
                                      "unilateral_job_change", "forced_resignation_pressure"]
            },
            "missing_elements": []
        },
        {
            "name": "Lose_Real案例",
            "verdict": VerdictTendency.LOSE,
            "judicial_analysis": {
                "elements_satisfied": ["mutual_consent"],
                "supporting_evidence": ["negotiated_separation", "voluntary_agreement"]
            },
            "missing_elements": ["contract_violation", "procedural_violation"]
        },
        {
            "name": "结构不足案例",
            "verdict": VerdictTendency.UNCERTAIN,
            "judicial_analysis": {
                "elements_satisfied": ["contract_exists"],
                "supporting_evidence": ["written_contract_violation"]
            },
            "missing_elements": ["termination_occurred", "lack_of_legal_basis"]
        }
    ]
    
    # 创建模拟的推理轨迹
    class MockReasoningTrace:
        def __init__(self, verdict: VerdictTendency, missing_elements: List[str]):
            self.verdict = verdict
            self.missing_elements = missing_elements
            self.reasoning_explanation = f"基于证据分析，判决倾向为{verdict.value}"
            self.supporting_factors = ["法律条文支持", "事实清楚"]
            self.opposing_factors = ["程序合规性存疑"]
    
    print("=== 分步骤奖励评估演示 ===\n")
    
    for case in test_cases:
        mock_trace = MockReasoningTrace(case["verdict"], case["missing_elements"])
        
        reward_breakdown = engine.evaluate(mock_trace, case["judicial_analysis"])
        
        print(f"案例: {case['name']}")
        print(f"判决倾向: {case['verdict'].value}")
        print(f"满足要件: {case['judicial_analysis']['elements_satisfied']}")
        print(f"支持证据: {case['judicial_analysis']['supporting_evidence']}")
        print(f"缺失要素: {case['missing_elements']}")
        print("\n分步骤评估:")
        for step in reward_breakdown.steps:
            print(f"  {step.name}: {step.score:.2f} - {step.explanation}")
        print(f"\n总奖励: {reward_breakdown.total_reward:.3f}")
        print(f"奖励类型: {reward_breakdown.reward_type.value}")
        print(f"总体解释: {reward_breakdown.explanation}")
        print("-" * 60)


# 如果直接运行此模块，则执行演示
if __name__ == "__main__":
    demo_stepwise_reward()
