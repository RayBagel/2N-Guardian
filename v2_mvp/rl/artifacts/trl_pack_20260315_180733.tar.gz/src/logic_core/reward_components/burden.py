def calculate_burden_reward(assistant_response: str) -> float:
    """
    在法律上代表：衡量助手回复中是否正确识别了举证责任分配问题
    输入：assistant 回复字符串（助手对举证责任归属的分析和建议）
    输出：float reward（0.0-1.0之间的浮点数，表示举证责任分析的准确性得分）
    """
    pass