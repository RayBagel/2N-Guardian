def calculate_illegality_reward(assistant_response: str) -> float:
    """
    在法律上代表：衡量助手回复中是否正确识别了用人单位行为的违法性
    输入：assistant 回复字符串（助手对用人单位行为是否违法的分析）
    输出：float reward（0.0-1.0之间的浮点数，表示违法性识别的准确性得分）
    """
    pass