"""
法律要素匹配器模块

根据"要件审判九步法"，将证据状态映射到法律要素。
此模块不作最终判断，仅识别要素是否满足、缺失或矛盾。
"""

from typing import Dict, List, Optional, Tuple
from enum import Enum
from ..evidence.evidence_state import EvidenceState, EvidenceSupport


class ElementStatus(Enum):
    """法律要素状态枚举"""
    SATISFIED = "satisfied"      # 要素满足
    MISSING = "missing"          # 要素缺失
    CONTRADICTED = "contradicted" # 要素矛盾


class ElementMatchResult:
    """要素匹配结果类"""
    def __init__(self, status: ElementStatus, supporting_evidence: List[str] = None, 
                 contradicting_evidence: List[str] = None):
        self.status = status
        self.supporting_evidence = supporting_evidence or []
        self.contradicting_evidence = contradicting_evidence or []


class LegalElementMatcher:
    """
    法律要素匹配器
    根据证据状态判断法律要素的满足情况
    """
    
    def __init__(self):
        # 定义非法解除劳动合同的法律要素
        self.illegal_termination_elements = {
            "contract_exists": {
                "name": "劳动合同存在",
                "required_evidence": [],
                "optional_evidence": [],
                "description": "确认劳动者与用人单位之间存在劳动合同关系"
            },
            "termination_occurred": {
                "name": "解除行为发生",
                "required_evidence": [],
                "optional_evidence": [],
                "description": "确认用人单位已实施解除劳动合同的行为"
            },
            "lack_of_legal_basis": {
                "name": "缺乏法定解除依据",
                "required_evidence": [
                    "written_contract_violation", 
                    "verbal_agreement_breach",
                    "discipline_policy_abuse",
                    "workplace_harassment",
                    "unilateral_job_change",
                    "forced_resignation_pressure",
                    "salary_withholding",
                    "social_insurance_violation",
                    "overtime_without_compensation"
                ],
                "optional_evidence": [
                    "legal_procedure_compliance"
                ],
                "description": "用人单位解除合同缺乏法定事由或程序不当"
            },
            "procedural_violation": {
                "name": "程序违法",
                "required_evidence": [
                    "legal_procedure_compliance"
                ],
                "optional_evidence": [],
                "description": "用人单位未履行法定解除程序（如未通知工会等）"
            }
        }
        
        # 定义协商解除劳动合同的法律要素
        self.mutual_agreement_elements = {
            "mutual_consent": {
                "name": "双方协商一致",
                "required_evidence": [
                    "negotiated_separation"
                ],
                "optional_evidence": [],
                "description": "双方当事人就解除劳动合同达成一致意见"
            },
            "voluntary_agreement": {
                "name": "自愿达成协议",
                "required_evidence": [],
                "optional_evidence": [
                    "forced_resignation_pressure"
                ],
                "description": "协议是在双方自愿基础上达成，无欺诈、胁迫情形"
            },
            "compliance_with_form": {
                "name": "符合法定形式",
                "required_evidence": [
                    "negotiated_separation"
                ],
                "optional_evidence": [],
                "description": "解除协议以书面形式达成"
            }
        }
    
    def match_illegal_termination_elements(self, evidence_state: EvidenceState) -> Dict[str, ElementMatchResult]:
        """
        匹配非法解除劳动合同的法律要素
        
        Args:
            evidence_state: 证据状态
            
        Returns:
            各法律要素的匹配结果
        """
        results = {}
        
        for element_key, element_info in self.illegal_termination_elements.items():
            required_evidence = element_info["required_evidence"]
            optional_evidence = element_info["optional_evidence"]
            
            # 检查必要证据
            required_satisfied = self._check_required_evidence(evidence_state, required_evidence)
            
            # 检查可选证据
            optional_supporting, optional_contradicting = self._check_optional_evidence(evidence_state, optional_evidence)
            
            # 根据证据情况确定要素状态
            status = self._determine_element_status(required_satisfied, optional_supporting, optional_contradicting, element_key)
            
            results[element_key] = ElementMatchResult(
                status=status,
                supporting_evidence=required_satisfied + optional_supporting,
                contradicting_evidence=optional_contradicting
            )
        
        return results
    
    def match_mutual_agreement_elements(self, evidence_state: EvidenceState) -> Dict[str, ElementMatchResult]:
        """
        匹配协商解除劳动合同的法律要素
        
        Args:
            evidence_state: 证据状态
            
        Returns:
            各法律要素的匹配结果
        """
        results = {}
        
        for element_key, element_info in self.mutual_agreement_elements.items():
            required_evidence = element_info["required_evidence"]
            optional_evidence = element_info["optional_evidence"]
            
            # 检查必要证据
            required_satisfied = self._check_required_evidence(evidence_state, required_evidence)
            
            # 检查可选证据
            optional_supporting, optional_contradicting = self._check_optional_evidence(evidence_state, optional_evidence)
            
            # 根据证据情况确定要素状态
            status = self._determine_element_status(required_satisfied, optional_supporting, optional_contradicting, element_key)
            
            results[element_key] = ElementMatchResult(
                status=status,
                supporting_evidence=required_satisfied + optional_supporting,
                contradicting_evidence=optional_contradicting
            )
        
        return results
    
    def _check_required_evidence(self, evidence_state: EvidenceState, required_evidence: List[str]) -> List[str]:
        """
        检查必要证据是否满足
        """
        satisfied_evidence = []
        
        for evidence_key in required_evidence:
            if hasattr(evidence_state, evidence_key):
                evidence_value = getattr(evidence_state, evidence_key)
                # 如果证据为True，则认为满足
                if evidence_value is True:
                    satisfied_evidence.append(evidence_key)
        
        return satisfied_evidence
    
    def _check_optional_evidence(self, evidence_state: EvidenceState, optional_evidence: List[str]) -> Tuple[List[str], List[str]]:
        """
        检查可选证据（支持性和矛盾性）
        """
        supporting_evidence = []
        contradicting_evidence = []
        
        for evidence_key in optional_evidence:
            if hasattr(evidence_state, evidence_key):
                evidence_value = getattr(evidence_state, evidence_key)
                
                if evidence_value is True:
                    supporting_evidence.append(evidence_key)
                elif evidence_value is False:
                    contradicting_evidence.append(evidence_key)
        
        return supporting_evidence, contradicting_evidence
    
    def _determine_element_status(self, required_satisfied: List[str], optional_supporting: List[str], 
                                  optional_contradicting: List[str], element_key: str) -> ElementStatus:
        """
        确定要素状态
        """
        # 对于某些特定要素，有不同的判断逻辑
        if element_key == "lack_of_legal_basis":
            # 对于"缺乏法定解除依据"要素，如果有支持证据，则满足；如果有矛盾证据，则矛盾
            if required_satisfied:
                return ElementStatus.SATISFIED
            elif optional_contradicting:
                return ElementStatus.CONTRADICTED
            else:
                return ElementStatus.MISSING
        elif element_key == "procedural_violation":
            # 对于"程序违法"要素
            if required_satisfied:  # 如果法律程序合规证据为真，则程序违法要素不成立
                # 需要重新理解这个逻辑：如果legal_procedure_compliance为True，说明程序合规，所以程序违法要素不满足
                # 因此，当legal_procedure_compliance为True时，procedural_violation要素应该是contradicted
                return ElementStatus.CONTRADICTED
            elif not required_satisfied and len(required_satisfied) > 0:  # 如果legal_procedure_compliance为False
                return ElementStatus.SATISFIED
            else:  # 如果legal_procedure_compliance为None
                return ElementStatus.MISSING
        elif element_key == "mutual_consent" or element_key == "compliance_with_form":
            # 对于协商一致要素，如果有协商解除证据，则满足
            if required_satisfied:
                return ElementStatus.SATISFIED
            elif optional_contradicting:  # 如果有强迫辞职压力证据，则矛盾
                return ElementStatus.CONTRADICTED
            else:
                return ElementStatus.MISSING
        elif element_key == "voluntary_agreement":
            # 对于自愿达成协议要素
            if optional_contradicting:  # 如果有强迫辞职压力证据，则矛盾
                return ElementStatus.CONTRADICTED
            elif optional_supporting:
                return ElementStatus.SATISFIED
            else:
                return ElementStatus.MISSING
        else:
            # 默认逻辑：只要有必要的证据满足，则要素满足
            if required_satisfied:
                return ElementStatus.SATISFIED
            elif optional_contradicting:
                return ElementStatus.CONTRADICTED
            else:
                return ElementStatus.MISSING
    
    def get_detailed_analysis(self, evidence_state: EvidenceState) -> Dict[str, any]:
        """
        获取详细分析结果
        
        Args:
            evidence_state: 证据状态
            
        Returns:
            包含非法解除和协商解除要素分析的详细结果
        """
        illegal_results = self.match_illegal_termination_elements(evidence_state)
        mutual_results = self.match_mutual_agreement_elements(evidence_state)
        
        # 统计各类状态的数量
        illegal_summary = self._summarize_results(illegal_results)
        mutual_summary = self._summarize_results(mutual_results)
        
        return {
            "illegal_termination_analysis": {
                "elements": illegal_results,
                "summary": illegal_summary
            },
            "mutual_agreement_analysis": {
                "elements": mutual_results,
                "summary": mutual_summary
            },
            "evidence_state_summary": evidence_state.summarize()
        }
    
    def _summarize_results(self, results: Dict[str, ElementMatchResult]) -> Dict[str, int]:
        """
        汇总结果统计
        """
        summary = {
            ElementStatus.SATISFIED.value: 0,
            ElementStatus.MISSING.value: 0,
            ElementStatus.CONTRADICTED.value: 0
        }
        
        for result in results.values():
            summary[result.status.value] += 1
        
        return summary


# 使用示例
def demo_element_matching():
    """
    演示要素匹配功能
    """
    matcher = LegalElementMatcher()
    
    # 创建一个示例证据状态
    evidence_state = EvidenceState()
    evidence_state.written_contract_violation = True
    evidence_state.legal_procedure_compliance = False
    evidence_state.negotiated_separation = False
    
    # 执行匹配
    analysis = matcher.get_detailed_analysis(evidence_state)
    
    print("=== 非法解除劳动合同要素分析 ===")
    for element_key, result in analysis["illegal_termination_analysis"]["elements"].items():
        print(f"{element_key}: {result.status.value}")
        if result.supporting_evidence:
            print(f"  支持证据: {result.supporting_evidence}")
        if result.contradicting_evidence:
            print(f"  矛盾证据: {result.contradicting_evidence}")
    
    print("\n=== 协商解除劳动合同要素分析 ===")
    for element_key, result in analysis["mutual_agreement_analysis"]["elements"].items():
        print(f"{element_key}: {result.status.value}")
        if result.supporting_evidence:
            print(f"  支持证据: {result.supporting_evidence}")
        if result.contradicting_evidence:
            print(f"  矛盾证据: {result.contradicting_evidence}")
    
    print(f"\n=== 总结 ===")
    print(f"非法解除分析: {analysis['illegal_termination_analysis']['summary']}")
    print(f"协商解除分析: {analysis['mutual_agreement_analysis']['summary']}")