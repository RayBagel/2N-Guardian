"""
司法三段论评估器模块

基于证据状态和要素匹配结果，进行司法三段论推理。
此模块仅基于法律规则进行推理，不使用机器学习或启发式算法。
"""

from enum import Enum
from typing import List, Dict, Any, Optional
from .element_matcher import LegalElementMatcher, ElementStatus, ElementMatchResult
from ..evidence.evidence_state import EvidenceState


class VerdictTendency(Enum):
    """判决倾向枚举"""
    WIN = "win"          # 员工胜诉
    LOSE = "lose"        # 员工败诉
    UNCERTAIN = "uncertain"  # 不确定


class ReasoningTrace:
    """推理轨迹类"""
    def __init__(self, verdict: VerdictTendency, missing_elements: List[str], 
                 reasoning_explanation: str, supporting_factors: List[str] = None, 
                 opposing_factors: List[str] = None):
        self.verdict = verdict
        self.missing_elements = missing_elements or []
        self.reasoning_explanation = reasoning_explanation
        self.supporting_factors = supporting_factors or []
        self.opposing_factors = opposing_factors or []


class SyllogismEvaluator:
    """
    司法三段论评估器
    基于证据状态和法律要素匹配结果进行司法推理
    """
    
    def __init__(self):
        self.element_matcher = LegalElementMatcher()
    
    def evaluate(self, evidence_state: EvidenceState, 
                 element_results: Dict[str, Dict[str, ElementMatchResult]] = None) -> ReasoningTrace:
        """
        评估判决倾向
        
        Args:
            evidence_state: 证据状态
            element_results: 要素匹配结果（可选，如果不提供则自动计算）
            
        Returns:
            ReasoningTrace: 推理轨迹和结果
        """
        # 如果没有提供要素匹配结果，则计算它们
        if element_results is None:
            element_results = self._compute_element_results(evidence_state)
        
        # 分析非法解除劳动合同的可能性
        illegal_termination_analysis = element_results["illegal_termination_analysis"]["elements"]
        mutual_agreement_analysis = element_results["mutual_agreement_analysis"]["elements"]
        
        # 计算判决倾向
        verdict, reasoning_explanation, missing_elements = self._analyze_verdict_tendency(
            illegal_termination_analysis, mutual_agreement_analysis
        )
        
        # 收集支持和反对因素
        supporting_factors, opposing_factors = self._collect_factors(
            illegal_termination_analysis, mutual_agreement_analysis
        )
        
        return ReasoningTrace(
            verdict=verdict,
            missing_elements=missing_elements,
            reasoning_explanation=reasoning_explanation,
            supporting_factors=supporting_factors,
            opposing_factors=opposing_factors
        )
    
    def _compute_element_results(self, evidence_state: EvidenceState) -> Dict[str, Dict[str, ElementMatchResult]]:
        """
        计算要素匹配结果
        """
        return self.element_matcher.get_detailed_analysis(evidence_state)
    
    def _analyze_verdict_tendency(self, illegal_termination_results: Dict[str, ElementMatchResult],
                                  mutual_agreement_results: Dict[str, ElementMatchResult]) -> tuple:
        """
        分析判决倾向
        
        根据劳动法原理：
        1. 如果构成非法解除劳动合同，则员工胜诉
        2. 如果构成协商解除劳动合同，则需看具体情况
        3. 如果都不构成，则可能败诉
        """
        # 统计各类要素状态
        illegal_satisfied = sum(1 for result in illegal_termination_results.values() 
                                if result.status == ElementStatus.SATISFIED)
        illegal_missing = sum(1 for result in illegal_termination_results.values() 
                              if result.status == ElementStatus.MISSING)
        illegal_contradicted = sum(1 for result in illegal_termination_results.values() 
                                   if result.status == ElementStatus.CONTRADICTED)
        
        mutual_satisfied = sum(1 for result in mutual_agreement_results.values() 
                               if result.status == ElementStatus.SATISFIED)
        mutual_missing = sum(1 for result in mutual_agreement_results.values() 
                             if result.status == ElementStatus.MISSING)
        mutual_contradicted = sum(1 for result in mutual_agreement_results.values() 
                                  if result.status == ElementStatus.CONTRADICTED)
        
        # 核心法律推理规则
        # 如果非法解除的关键要素（如缺乏法定依据）得到满足，则倾向于员工胜诉
        lack_of_legal_basis_satisfied = (
            illegal_termination_results.get("lack_of_legal_basis", ElementMatchResult(ElementStatus.MISSING)).status == ElementStatus.SATISFIED
        )
        
        procedural_violation_satisfied = (
            illegal_termination_results.get("procedural_violation", ElementMatchResult(ElementStatus.MISSING)).status == ElementStatus.SATISFIED
        )
        
        # 如果协商解除的关键要素得到满足，则倾向于用人单位
        mutual_consent_satisfied = (
            mutual_agreement_results.get("mutual_consent", ElementMatchResult(ElementStatus.MISSING)).status == ElementStatus.SATISFIED
        )
        
        # 推理逻辑
        if lack_of_legal_basis_satisfied or procedural_violation_satisfied:
            # 如果用人单位缺乏合法解除依据或程序违法，则倾向于员工胜诉
            missing_elements = self._get_missing_elements_for_case(illegal_termination_results, "supporting_employee")
            explanation = (
                "用人单位解除劳动合同缺乏法定依据或程序违法，根据《劳动合同法》相关规定，"
                "用人单位应当承担违法解除劳动合同的法律责任。现有证据支持员工胜诉。"
            )
            return VerdictTendency.WIN, explanation, missing_elements
                
        elif mutual_consent_satisfied and not mutual_contradicted:
            # 如果双方协商一致解除劳动合同，则倾向于用人单位
            missing_elements = self._get_missing_elements_for_case(illegal_termination_results, "supporting_employer")
            explanation = (
                "双方协商一致解除劳动合同，符合《劳动合同法》第三十六条的规定。"
                "在双方自愿的基础上达成的协议具有法律效力，员工主张违法解除劳动合同的请求难以成立。"
            )
            return VerdictTendency.LOSE, explanation, missing_elements
                
        elif mutual_contradicted and illegal_contradicted:
            # 如果协商解除被否定（如存在强迫辞职压力），且非法解除的部分要素被满足
            missing_elements = self._get_missing_elements_for_case(illegal_termination_results, "supporting_employee")
            explanation = (
                "虽然用人单位声称系协商一致解除劳动合同，但存在强迫员工辞职的情形，"
                "且用人单位在解除过程中可能存在程序违法或其他违法行为，"
                "根据《劳动合同法》相关规定，倾向于认定为违法解除。"
            )
            return VerdictTendency.WIN, explanation, missing_elements
        
        elif illegal_satisfied > illegal_contradicted and illegal_satisfied >= 2:
            # 如果多数非法解除要素得到满足
            missing_elements = self._get_missing_elements_for_case(illegal_termination_results, "supporting_employee")
            explanation = (
                "多项证据表明用人单位解除劳动合同的行为存在违法情形，"
                "根据优势证据原则和《劳动合同法》相关规定，倾向于认定为违法解除。"
            )
            return VerdictTendency.WIN, explanation, missing_elements
        
        elif mutual_satisfied > mutual_contradicted and mutual_satisfied >= 2:
            # 如果多数协商解除要素得到满足
            missing_elements = self._get_missing_elements_for_case(illegal_termination_results, "supporting_employer")
            explanation = (
                "多项证据表明劳动合同系双方协商一致解除，"
                "用人单位已履行相应法律义务，员工主张违法解除的请求难以成立。"
            )
            return VerdictTendency.LOSE, explanation, missing_elements
        
        else:
            # 证据不足或相互矛盾，难以确定
            missing_elements = self._get_missing_elements_for_case(illegal_termination_results, "uncertain")
            explanation = (
                "现有证据不足以明确证明用人单位解除劳动合同的行为是否违法，"
                "或证据存在相互矛盾之处，难以形成优势证据，判决结果不确定。"
            )
            return VerdictTendency.UNCERTAIN, explanation, missing_elements
    
    def _get_missing_elements_for_case(self, element_results: Dict[str, ElementMatchResult], 
                                       case_type: str) -> List[str]:
        """
        获取缺失的要素列表
        """
        missing = []
        for element_key, result in element_results.items():
            if result.status == ElementStatus.MISSING:
                missing.append(element_key)
        return missing
    
    def _collect_factors(self, illegal_termination_results: Dict[str, ElementMatchResult],
                         mutual_agreement_results: Dict[str, ElementMatchResult]) -> tuple:
        """
        收集支持和反对因素
        """
        supporting_factors = []
        opposing_factors = []
        
        # 收集非法解除相关因素
        for element_key, result in illegal_termination_results.items():
            if result.status == ElementStatus.SATISFIED:
                supporting_factors.extend(result.supporting_evidence)
            elif result.status == ElementStatus.CONTRADICTED:
                opposing_factors.extend(result.contradicting_evidence)
        
        # 收集协商解除相关因素
        for element_key, result in mutual_agreement_results.items():
            if result.status == ElementStatus.SATISFIED:
                opposing_factors.extend(result.supporting_evidence)  # 协商解除对员工不利
            elif result.status == ElementStatus.CONTRADICTED:
                supporting_factors.extend(result.contradicting_evidence)  # 协商解除被否定对员工有利
        
        return list(set(supporting_factors)), list(set(opposing_factors))


# 使用示例
def demo_syllogism_evaluation():
    """
    演示三段论评估功能
    """
    evaluator = SyllogismEvaluator()
    
    # 创建一个示例证据状态
    evidence_state = EvidenceState()
    evidence_state.written_contract_violation = True  # 书面合同条款违反
    evidence_state.legal_procedure_compliance = False  # 程序不合规
    evidence_state.negotiated_separation = False  # 非协商解除
    
    # 执行评估
    result = evaluator.evaluate(evidence_state)
    
    print("=== 三段论评估结果 ===")
    print(f"判决倾向: {result.verdict.value}")
    print(f"推理说明: {result.reasoning_explanation}")
    print(f"缺失要素: {result.missing_elements}")
    print(f"支持因素: {result.supporting_factors}")
    print(f"反对因素: {result.opposing_factors}")
    
    return result