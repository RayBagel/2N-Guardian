"""
Filter training data with current legal reward pipeline.

Usage:
  python -m src.data_engine.filter_data \
    --input data/train.jsonl \
    --output data/clean_train_data.jsonl \
    --threshold 0.0
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Iterable, Tuple

from src.logic_core.evidence.evidence_state import EvidenceState
from src.logic_core.evidence.evidence_tracker import EvidenceTracker
from src.logic_core.legal_reasoning.element_matcher import ElementStatus, LegalElementMatcher
from src.logic_core.legal_reasoning.syllogism_evaluator import SyllogismEvaluator
from src.logic_core.reward.reward_adapter import RewardAdapter


def iter_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def dump_jsonl(path: Path, rows: Iterable[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


class RewardScorer:
    """Adapter around current parser + reward pipeline."""

    def __init__(self) -> None:
        self.evidence_tracker = EvidenceTracker()
        self.element_matcher = LegalElementMatcher()
        self.syllogism_evaluator = SyllogismEvaluator()
        self.reward_adapter = RewardAdapter()

    def _extract_judicial_analysis(
        self,
        element_results: Dict[str, Any],
        evidence_state: EvidenceState,
        assistant_text: str = "",
    ) -> Dict[str, Any]:
        elements_satisfied = []
        illegal_elements = element_results.get("illegal_termination_analysis", {}).get("elements", {})
        mutual_elements = element_results.get("mutual_agreement_analysis", {}).get("elements", {})

        for element_key, element_result in illegal_elements.items():
            if element_result.status == ElementStatus.SATISFIED:
                elements_satisfied.append(element_key)
        for element_key, element_result in mutual_elements.items():
            if element_result.status == ElementStatus.SATISFIED:
                elements_satisfied.append(element_key)

        summary = evidence_state.summarize()
        supporting_evidence = [k for k, v in summary.items() if v is True]
        confidence_map = getattr(evidence_state, "_evidence_confidence", {})

        return {
            "elements_satisfied": elements_satisfied,
            "supporting_evidence": supporting_evidence,
            "supporting_evidence_confidence": dict(confidence_map),
            "assistant_raw_text": str(assistant_text or ""),
        }

    def score_row(self, row: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
        dialogue_turn = {
            "system": str(row.get("system", "")),
            "user": str(row.get("user", "")),
            "assistant": str(row.get("assistant", "")),
        }
        initial_state = EvidenceState()
        evidence_state = self.evidence_tracker.update(initial_state, dialogue_turn)
        element_results = self.element_matcher.get_detailed_analysis(evidence_state)
        reasoning_result = self.syllogism_evaluator.evaluate(evidence_state, element_results)
        judicial_analysis = self._extract_judicial_analysis(
            element_results,
            evidence_state,
            assistant_text=str(row.get("assistant", "")),
        )

        outcome = str(row.get("outcome", "")).lower()
        if outcome.startswith("win"):
            judicial_analysis["outcome"] = "win"
        elif outcome.startswith("lose"):
            judicial_analysis["outcome"] = "lose"
        else:
            judicial_analysis["outcome"] = "uncertain"
        judicial_analysis["ground_truth"] = str(row.get("ground_truth", "")).lower()
        judicial_analysis["is_real_case"] = str(row.get("ground_truth", "")).lower().endswith("_real")

        reward_result = self.reward_adapter.adapt(reasoning_result, judicial_analysis)
        breakdown = {
            "reward_components": reward_result.components,
            "reward_type": getattr(reward_result.reward_type, "value", str(reward_result.reward_type)),
            "explanation": reward_result.explanation,
            "elements_satisfied": reward_result.elements_satisfied,
            "supporting_evidence": reward_result.supporting_evidence,
            "missing_elements": reward_result.missing_elements,
        }
        return float(reward_result.total_reward), breakdown


def main() -> None:
    parser = argparse.ArgumentParser(description="Filter JSONL training data by legal reward.")
    parser.add_argument("--input", default="data/train.jsonl", help="Input JSONL path.")
    parser.add_argument("--output", default="data/clean_train_data.jsonl", help="Output JSONL path.")
    parser.add_argument("--threshold", type=float, default=0.0, help="Keep rows with reward >= threshold.")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    scorer = RewardScorer()
    total = 0
    kept = 0
    filtered_rows = []

    for row in iter_jsonl(input_path):
        total += 1
        reward, breakdown = scorer.score_row(row)
        if reward >= args.threshold:
            row["total_reward"] = reward
            row["reward_breakdown"] = breakdown
            filtered_rows.append(row)
            kept += 1

    dump_jsonl(output_path, filtered_rows)
    print(f"Input samples: {total}")
    print(f"Kept samples (>= {args.threshold}): {kept}")
    print(f"Dropped samples: {total - kept}")
    print(f"Output path: {output_path}")


if __name__ == "__main__":
    main()
