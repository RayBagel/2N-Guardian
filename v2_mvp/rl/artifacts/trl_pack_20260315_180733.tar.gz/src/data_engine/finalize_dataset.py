"""
Finalize training dataset by mixing cleaned base data + augmented data.

Pipeline:
1) Re-score base data from data/train.jsonl -> list A
2) Load augmented data from data/augmented_train_data.jsonl -> list B
3) Merge + exact deduplicate + semantic cosine deduplicate
4) Dynamic filter with reward percentile (default P65)
5) Save to data/final_train.jsonl and print statistics
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import math
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

import numpy as np

from src.data_engine.filter_data import RewardScorer, dump_jsonl, iter_jsonl


def content_fingerprint(row: Dict[str, Any]) -> str:
    """
    Stable hash based on core training content.
    """
    system_text = str(row.get("system", "")).strip()
    user_text = str(row.get("user", "")).strip()
    assistant_text = str(row.get("assistant", "")).strip()
    payload = "||".join([system_text, user_text, assistant_text])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def build_clean_base_rows(input_path: Path) -> List[Dict[str, Any]]:
    scorer = RewardScorer()
    rows: List[Dict[str, Any]] = []
    for row in iter_jsonl(input_path):
        reward, breakdown = scorer.score_row(row)
        enriched = dict(row)
        enriched["total_reward"] = reward
        enriched["reward_breakdown"] = breakdown
        enriched["_source"] = "base_clean"
        rows.append(enriched)
    return rows


def _safe_reward(row: Dict[str, Any]) -> float:
    try:
        return float(row.get("total_reward", 0.0))
    except (TypeError, ValueError):
        return 0.0


def _char_ngram_counter(text: str, n: int = 3) -> Counter:
    normalized = "".join(str(text).split()).lower()
    if len(normalized) < n:
        return Counter({normalized: 1}) if normalized else Counter()
    return Counter(normalized[i : i + n] for i in range(len(normalized) - n + 1))


def _cosine_similarity(vec_a: Counter, vec_b: Counter) -> float:
    if not vec_a or not vec_b:
        return 0.0
    common_keys = set(vec_a.keys()) & set(vec_b.keys())
    dot = sum(vec_a[k] * vec_b[k] for k in common_keys)
    norm_a = math.sqrt(sum(v * v for v in vec_a.values()))
    norm_b = math.sqrt(sum(v * v for v in vec_b.values()))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return float(dot / (norm_a * norm_b))


def _semantic_payload(row: Dict[str, Any]) -> str:
    return " ".join(
        [
            str(row.get("system", "")),
            str(row.get("user", "")),
            str(row.get("assistant", "")),
        ]
    )


def load_augmented_rows(aug_path: Path) -> List[Dict[str, Any]]:
    """
    Supports both:
    - JSONL (one object per line)
    - JSON array file
    """
    rows: List[Dict[str, Any]] = []
    try:
        for row in iter_jsonl(aug_path):
            enriched = dict(row)
            enriched["_source"] = "augmented"
            rows.append(enriched)
        return rows
    except Exception:
        pass

    with aug_path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        raise ValueError(f"Unsupported augmented file format: {aug_path}")

    for row in data:
        if isinstance(row, dict):
            enriched = dict(row)
            enriched["_source"] = "augmented"
            rows.append(enriched)
    return rows


def merge_and_deduplicate(
    base_rows: List[Dict[str, Any]],
    augmented_rows: List[Dict[str, Any]],
    similarity_threshold: float = 0.9,
) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """
    Prefer base rows when duplicates occur (more stable anchor data).
    """
    seen_case_ids: Set[str] = set()
    seen_hashes: Set[str] = set()
    merged: List[Dict[str, Any]] = []
    stats = {
        "base_input": len(base_rows),
        "aug_input": len(augmented_rows),
        "dup_by_case_id": 0,
        "dup_by_content_hash": 0,
        "kept_base": 0,
        "kept_aug": 0,
        "dup_by_semantic": 0,
    }

    def try_add(row: Dict[str, Any]) -> None:
        case_id = str(row.get("case_id", "")).strip()
        fp = content_fingerprint(row)

        if case_id and case_id in seen_case_ids:
            stats["dup_by_case_id"] += 1
            return
        if fp in seen_hashes:
            stats["dup_by_content_hash"] += 1
            return

        merged.append(row)
        if case_id:
            seen_case_ids.add(case_id)
        seen_hashes.add(fp)

        if row.get("_source") == "base_clean":
            stats["kept_base"] += 1
        elif row.get("_source") == "augmented":
            stats["kept_aug"] += 1

    # Keep base first as anchor, then add augmented.
    for row in base_rows:
        try_add(row)
    for row in augmented_rows:
        try_add(row)

    # 语义向量去重：若相似度 > 阈值，仅保留 reward 更高样本。
    by_reward = sorted(merged, key=_safe_reward, reverse=True)
    semantic_kept: List[Dict[str, Any]] = []
    semantic_vectors: List[Counter] = []
    for row in by_reward:
        row_vec = _char_ngram_counter(_semantic_payload(row))
        is_dup = False
        for kept_vec in semantic_vectors:
            if _cosine_similarity(row_vec, kept_vec) > similarity_threshold:
                is_dup = True
                stats["dup_by_semantic"] += 1
                break
        if not is_dup:
            semantic_kept.append(row)
            semantic_vectors.append(row_vec)
    merged = semantic_kept

    # remove internal helper field
    for row in merged:
        row.pop("_source", None)

    return merged, stats


def print_stats(stats: Dict[str, int], final_count: int) -> None:
    kept_base = stats["kept_base"]
    kept_aug = stats["kept_aug"]
    base_ratio = (kept_base / final_count * 100.0) if final_count else 0.0
    aug_ratio = (kept_aug / final_count * 100.0) if final_count else 0.0

    print(f"Final training samples: {final_count}")
    print(f"Kept base_clean: {kept_base} ({base_ratio:.2f}%)")
    print(f"Kept augmented: {kept_aug} ({aug_ratio:.2f}%)")
    print(f"Duplicates removed by case_id: {stats['dup_by_case_id']}")
    print(f"Duplicates removed by content_hash: {stats['dup_by_content_hash']}")
    print(f"Duplicates removed by semantic cosine: {stats['dup_by_semantic']}")


def apply_dynamic_reward_filter(rows: List[Dict[str, Any]], quantile: float) -> Tuple[List[Dict[str, Any]], float]:
    if not rows:
        return [], 0.0
    rewards = np.array([_safe_reward(r) for r in rows], dtype=float)
    cutoff = float(np.percentile(rewards, quantile))
    filtered = [row for row in rows if _safe_reward(row) >= cutoff]
    if not filtered:
        best = max(rows, key=_safe_reward)
        return [best], cutoff
    return filtered, cutoff


def main() -> None:
    parser = argparse.ArgumentParser(description="Finalize mixed training dataset.")
    parser.add_argument("--base-input", default="data/train.jsonl", help="Raw base dataset JSONL.")
    parser.add_argument("--aug-input", default="data/augmented_train_data.jsonl", help="Augmented dataset JSONL.")
    parser.add_argument("--output", default="data/final_train.jsonl", help="Final merged dataset JSONL.")
    parser.add_argument("--quantile", type=float, default=65.0, help="Dynamic reward quantile cutoff (0-100).")
    parser.add_argument("--semantic-threshold", type=float, default=0.9, help="Cosine similarity threshold for semantic dedup.")
    args = parser.parse_args()

    # Reduce noise from tracker INFO logs during bulk scoring.
    logging.getLogger("src.logic_core.evidence.evidence_tracker").setLevel(logging.WARNING)

    base_input = Path(args.base_input)
    aug_input = Path(args.aug_input)
    output = Path(args.output)

    if not base_input.exists():
        raise FileNotFoundError(f"Base input not found: {base_input}")
    if not aug_input.exists():
        raise FileNotFoundError(f"Augmented input not found: {aug_input}")

    base_rows = build_clean_base_rows(base_input)
    augmented_rows = load_augmented_rows(aug_input)
    merged_rows, stats = merge_and_deduplicate(
        base_rows,
        augmented_rows,
        similarity_threshold=args.semantic_threshold,
    )
    final_rows, cutoff = apply_dynamic_reward_filter(merged_rows, quantile=args.quantile)

    dump_jsonl(output, final_rows)
    print_stats(stats, final_count=len(final_rows))
    print(f"Dynamic reward cutoff (P{args.quantile:.0f}): {cutoff:.4f}")
    print(f"Output path: {output}")


if __name__ == "__main__":
    main()
