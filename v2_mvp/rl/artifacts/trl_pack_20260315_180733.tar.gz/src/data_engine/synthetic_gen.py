import json
import os
from pathlib import Path
from typing import List, Dict, Any
import yaml
from openai import OpenAI


def load_config(config_path: str = "configs/config.yaml") -> Dict[str, Any]:
    """加载配置文件"""
    _load_dotenv()

    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # 安全优先：环境变量覆盖配置文件中的api_key
    env_api_key = os.getenv("SILICONFLOW_API_KEY") or os.getenv("OPENAI_API_KEY")
    if env_api_key:
        config.setdefault("api", {})["api_key"] = env_api_key

    return config


def _load_dotenv() -> None:
    """
    读取项目根目录 .env（如存在）并注入环境变量。
    仅在变量尚未存在时写入，避免覆盖外部已配置值。
    """
    root = Path(__file__).resolve().parents[2]
    env_path = root / ".env"
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def require_api_key(config: Dict[str, Any]) -> str:
    """获取可用 API Key，不存在则抛错"""
    api_key = config.get("api", {}).get("api_key", "")
    if not api_key:
        raise ValueError(
            "缺少 API Key。请设置环境变量 SILICONFLOW_API_KEY（或 OPENAI_API_KEY）。"
        )
    return api_key


def load_case_data(json_file_path: str) -> List[Dict[str, Any]]:
    """
    从JSON文件加载案例数据
    """
    import pdfplumber
    from pathlib import Path
    
    # 首先尝试从原始PDF中提取详细案例数据
    pdf_dir = Path("knowledge_base/raw_pdfs")
    pdf_files = list(pdf_dir.glob("*.pdf"))
    
    print(f"发现 {len(pdf_files)} 个原始PDF案例文件")
    
    cases = []
    
    # 从PDF文件中提取案例数据
    for i, pdf_file in enumerate(pdf_files):
        # 提取PDF内容
        try:
            with pdfplumber.open(pdf_file) as pdf:
                text = ""
                for page in pdf.pages[:3]:  # 提取前3页
                    text += page.extract_text() or ""
                
                # 模拟提取HR话术和法官判理
                hr_tactic = extract_hr_tactic_from_text(text)
                judge_reason = extract_judge_reason_from_text(text)
                outcome = extract_outcome_from_text(text)
                
                case = {
                    'case_id': f'original_case_{i+1}_{pdf_file.stem}',
                    'result': outcome,
                    'reason': judge_reason if judge_reason else text[:200] + "...",
                    'hr_tactic': hr_tactic if hr_tactic else "用人单位施压行为",
                    'judge_reason': judge_reason if judge_reason else "法院判决理由"
                }
                
                cases.append(case)
                
        except Exception as e:
            print(f"处理PDF文件 {pdf_file.name} 时出错: {str(e)}")
            continue
    
    # 如果没有从PDF中提取到足够的案例，也从evidence_map.json中补充
    if len(cases) < 5:  # 如果PDF提取的案例太少
        print("从evidence_map.json中补充案例数据...")
        try:
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 补充胜诉案例
            for i, winning_point in enumerate(data['winning_commonalities']):
                case = {
                    'case_id': f'winning_case_{i+1}',
                    'result': 'win',
                    'reason': winning_point,
                    'hr_tactic': '通用HR施压话术',
                    'judge_reason': winning_point
                }
                cases.append(case)
            
            # 补充败诉案例
            for i, losing_point in enumerate(data['losing_commonalities']):
                case = {
                    'case_id': f'losing_case_{i+1}',
                    'result': 'lose',
                    'reason': losing_point,
                    'hr_tactic': '通用HR施压话术',
                    'judge_reason': losing_point
                }
                cases.append(case)
        except Exception as e:
            print(f"加载evidence_map.json时出错: {str(e)}")
    
    return cases


def extract_hr_tactic_from_text(text: str) -> str:
    """
    从PDF文本中提取HR话术（简化版）
    """
    # 这里应该实现更复杂的文本分析逻辑
    # 简单关键词匹配
    import re
    
    # 寻找可能的HR话术表述
    hr_patterns = [
        r'公司.*?[说,表示,称,要求].*?[您,你,员工].*?',
        r'HR.*?[告知,通知,要求].*?',
        r'单位.*?[决定,要求].*?'
    ]
    
    for pattern in hr_patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(0)[:200]  # 返回前200字符
    
    return ""


def extract_judge_reason_from_text(text: str) -> str:
    """
    从PDF文本中提取法官判理（简化版）
    """
    import re
    
    # 寻找可能的法官判理表述
    judge_patterns = [
        r'法院.*?认为.*?[。.!?]',
        r'本院.*?认定.*?[。.!?]',
        r'判决.*?[。.!?]',
        r'裁定.*?[。.!?]'
    ]
    
    for pattern in judge_patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(0)
    
    return ""


def extract_outcome_from_text(text: str) -> str:
    """
    从PDF文本中提取判决结果（简化版）
    """
    import re
    
    # 检查是否包含败诉关键词
    losing_keywords = ['驳回', '败诉', '不予支持', '维持原判', '维持', '输']
    winning_keywords = ['胜诉', '支持', '撤销', '改判']
    
    text_lower = text.lower()
    
    losing_count = sum(1 for kw in losing_keywords if kw in text_lower)
    winning_count = sum(1 for kw in winning_keywords if kw in text_lower)
    
    if losing_count > winning_count:
        return 'lose'
    elif winning_count > losing_count:
        return 'win'
    else:
        return 'unknown'


def test_api_connection(config: Dict[str, Any]) -> bool:
    """
    测试API连接是否正常
    """
    try:
        api_config = config['api']
        client = OpenAI(
            base_url=api_config['base_url'],
            api_key=require_api_key(config)
        )
        model = api_config['model']
        
        # 发送一个简单的测试请求
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "user", "content": "你好，请回复'API连接正常'。"}
            ],
            temperature=0.1,
            max_tokens=20
        )
        
        print("API连接测试成功！")
        return True
        
    except Exception as e:
        print(f"API连接测试失败: {str(e)}")
        return False


def generate_synthetic_data(cases: List[Dict[str, Any]], config: Dict[str, Any], total_samples: int = 500) -> List[Dict[str, Any]]:
    """
    基于真实案例生成合成数据
    """
    # 先测试API连接
    if not test_api_connection(config):
        print("API连接失败，将使用模拟数据生成。")
        return generate_fallback_data(cases, total_samples)
    
    # 初始化API客户端
    api_config = config['api']
    client = OpenAI(
        base_url=api_config['base_url'],
        api_key=require_api_key(config)
    )
    model = api_config['model']
    
    synthetic_data = []
    
    # 计算每个案例需要扩展的数量
    samples_per_case = max(1, total_samples // len(cases))
    
    print(f"开始生成合成数据，共 {len(cases)} 个种子案例，每个案例扩展 {samples_per_case} 次...")
    
    for i, case in enumerate(cases):
        print(f"正在处理第 {i+1}/{len(cases)} 个案例...")
        
        for j in range(samples_per_case):
            try:
                if case['result'] == 'win':
                    # 策略 A：胜诉案例 -> 正向强化
                    system_prompt = f"""你是一个法律博弈专家。基于这个真实的胜诉案例，重现员工的高明操作。
                    
                    法官支持的胜诉理由：{case['judge_reason']}
                    """
                    
                    user_prompt = f"""这是HR的真实施压话术，请生成员工的高明应对策略：
                    {case['hr_tactic'] if case['hr_tactic'] else '请基于胜诉理由生成典型的HR施压话术'}
                    """
                    
                    response = client.chat.completions.create(
                        model=model,
                        messages=[
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_prompt}
                        ],
                        temperature=0.7,
                        max_tokens=1000
                    )
                    
                    ai_response = response.choices[0].message.content
                    
                    # 构造输出格式
                    sample = {
                        "system": system_prompt,
                        "user": user_prompt,
                        "assistant": f"<thought>法官支持这种证据是因为{case['judge_reason']}，所以员工需要采用相应的取证策略。</thought>\n\n<response>{ai_response}</response>",
                        "case_id": case['case_id'],
                        "strategy": "positive_reinforcement",
                        "outcome": "win"
                    }
                    
                else:
                    # 策略 B：败诉案例 -> 负向修正
                    system_prompt = f"""你是一个法律救援专家。这是一个真实的败诉案例，原告员工因为掉入了 HR 的陷阱而败诉。
                    
                    败诉原因：{case['reason']}
                    你的任务是时光倒流，修正这个错误。
                    """
                    
                    user_prompt = f"""这是导致败诉的 HR 话术，请生成员工应该采用的正确应对方式：
                    {case['hr_tactic'] if case['hr_tactic'] else '请基于败诉原因生成典型的HR施压话术'}
                    """
                    
                    response = client.chat.completions.create(
                        model=model,
                        messages=[
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_prompt}
                        ],
                        temperature=0.7,
                        max_tokens=1000
                    )
                    
                    ai_response = response.choices[0].message.content
                    
                    # 构造输出格式
                    sample = {
                        "system": system_prompt,
                        "user": user_prompt,
                        "assistant": f"<thought>原案例员工错在{case['reason']}，这被法官认定为不利因素。正确的应对策略是...</thought>\n\n<response>应该拒绝HR的要求，并明确表达：{ai_response}</response>",
                        "case_id": case['case_id'],
                        "strategy": "negative_correction",
                        "outcome": "lose_avoided"
                    }
                
                synthetic_data.append(sample)
                
            except Exception as e:
                print(f"处理案例 {case['case_id']} 时发生错误: {str(e)}")
                # 添加一个默认样本以保持期望的数据量
                default_sample = {
                    "system": "你是一个法律博弈专家。",
                    "user": "请提供一个通用的员工应对HR施压的策略。",
                    "assistant": f"<thought>这是一个通用的应对策略示例。</thought>\n\n<response>员工应当了解自己的权利，并在面对HR施压时保持冷静，记录重要对话，并寻求法律咨询。</response>",
                    "case_id": case['case_id'],
                    "strategy": "fallback_strategy",
                    "outcome": "neutral"
                }
                synthetic_data.append(default_sample)
    
    return synthetic_data


def generate_fallback_data(cases: List[Dict[str, Any]], total_samples: int) -> List[Dict[str, Any]]:
    """
    当API连接失败时，使用模拟数据生成
    """
    print("使用模拟数据生成替代方案...")
    synthetic_data = []
    
    # 计算每个案例需要扩展的数量
    samples_per_case = max(1, total_samples // len(cases))
    
    for i, case in enumerate(cases):
        for j in range(samples_per_case):
            if case['result'] == 'win':
                sample = {
                    "system": f"你是一个法律博弈专家。基于这个真实的胜诉案例，重现员工的高明操作。法官支持的胜诉理由：{case['judge_reason']}",
                    "user": f"这是HR的真实施压话术，请生成员工的高明应对策略：请基于胜诉理由生成典型的HR施压话术",
                    "assistant": f"<thought>法官支持这种证据是因为{case['judge_reason']}，所以员工需要采用相应的取证策略。</thought>\n\n<response>员工应坚持自己的合法权益，要求HR提供书面通知，并保留相关证据。</response>",
                    "case_id": case['case_id'],
                    "strategy": "positive_reinforcement",
                    "outcome": "win"
                }
            else:
                sample = {
                    "system": f"你是一个法律救援专家。这是一个真实的败诉案例，原告员工因为掉入了 HR 的陷阱而败诉。败诉原因：{case['reason']} 你的任务是时光倒流，修正这个错误。",
                    "user": f"这是导致败诉的 HR 话术，请生成员工应该采用的正确应对方式：请基于败诉原因生成典型的HR施压话术",
                    "assistant": f"<thought>原案例员工错在{case['reason']}，这被法官认定为不利因素。正确的应对策略是...</thought>\n\n<response>应该拒绝HR的要求，并明确表达：员工有权要求书面通知，并会寻求法律咨询。</response>",
                    "case_id": case['case_id'],
                    "strategy": "negative_correction",
                    "outcome": "lose_avoided"
                }
            
            synthetic_data.append(sample)
    
    return synthetic_data


def save_synthetic_data(data: List[Dict[str, Any]], output_path: str):
    """
    保存合成数据到JSONL文件
    """
    output_dir = Path(output_path).parent
    output_dir.mkdir(parents=True, exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')
    
    print(f"合成数据已保存至: {output_path}")


def main():
    """
    主函数：执行完整的合成数据生成流程
    """
    print("开始执行合成数据生成流程...")
    
    # 加载配置
    config = load_config()
    
    # 读取案例数据
    evidence_map_path = "data/evidence_map.json"
    if not os.path.exists(evidence_map_path):
        print(f"错误：找不到案例数据文件 {evidence_map_path}")
        return
    
    cases = load_case_data(evidence_map_path)
    print(f"加载了 {len(cases)} 个案例数据")
    
    if not cases:
        print("没有找到有效的案例数据")
        return
    
    # 生成合成数据
    synthetic_data = generate_synthetic_data(cases, config)
    
    # 保存结果
    output_path = "data/train.jsonl"
    save_synthetic_data(synthetic_data, output_path)
    
    print(f"合成数据生成完成！")
    print(f"总计生成 {len(synthetic_data)} 条训练数据")
    print(f"输出文件: {output_path}")


if __name__ == "__main__":
    main()
