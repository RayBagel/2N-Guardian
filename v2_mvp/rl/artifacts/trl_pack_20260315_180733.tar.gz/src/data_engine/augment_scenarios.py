"""
SiliconFlow-compatible scenario augmentation pipeline.

Rebuild strategy:
1) Win seeds  -> generate "程序伪漏洞" contrast variants
2) Lose seeds -> generate "证据翻盘" contrast variants
3) Force <THINKING> declaration for reward-targeted stress tests
4) Score with reward adapter + dynamic quantile filtering
"""

from __future__ import annotations

import argparse
import json
import os
import random
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from dotenv import load_dotenv
from openai import OpenAI
from tqdm import tqdm

from src.logic_core.evidence.evidence_state import EvidenceState
from src.logic_core.evidence.evidence_tracker import EvidenceTracker
from src.logic_core.legal_reasoning.element_matcher import ElementStatus, LegalElementMatcher
from src.logic_core.legal_reasoning.syllogism_evaluator import SyllogismEvaluator
from src.logic_core.reward.reward_adapter import RewardAdapter

SYSTEM_CHAOS = (
    "你是一个法律博弈数据增强器。"
    "你必须生成可用于 Reward 压力测试的对比案例，不得输出泛化废话。"
)

WIN_PSEUDO_VULNERABILITY_TEMPLATE = (
    "你将基于胜诉种子，构造“程序伪漏洞”对比组（不是简单复述）。\n"
    "种子上下文：\n{case_context}\n\n"
    "输出 {variant_count} 条 JSON 数组，每项必须是对象并包含字段：\n"
    "- variant_type: 固定为 \"程序伪漏洞对比组\"\n"
    "- test_metric: 从[程序时效, 送达瑕疵, 管辖异议, 程序合规性, 举证责任分配]中选1个\n"
    "- thinking: 必须是 <THINKING>...</THINKING>，明确写“本变种用于测试 Reward 指标: xxx”\n"
    "- scenario: 案情正文，强调实体证据强，但故意加入可辩驳的程序争点\n"
    "只输出 JSON，不要额外文字。"
)

LOSE_EVIDENCE_COMEBACK_TEMPLATE = (
    "你将基于败诉种子，构造“证据翻盘”对比组（不是简单改写）。\n"
    "种子上下文：\n{case_context}\n\n"
    "输出 {variant_count} 条 JSON 数组，每项必须是对象并包含字段：\n"
    "- variant_type: 固定为 \"证据翻盘对比组\"\n"
    "- test_metric: 从[证据链完整性, 关键证据合法性, 证据三性, 证明责任转移, 程序时效]中选1个\n"
    "- thinking: 必须是 <THINKING>...</THINKING>，明确写“本变种用于测试 Reward 指标: xxx”\n"
    "- scenario: 案情正文，强调如何补齐证据链并扭转败诉风险\n"
    "只输出 JSON，不要额外文字。"
)

SYSTEM_EXPERT = (
    "你是一个资深诉讼律师。\n"
    "你的任务是针对案情进行深度法律分析，并输出可被 Reward 组件稳定识别的结构。\n"
    "为了确保分析的专业性，你必须严格按照以下格式输出，不得省略标题：\n\n"
    "<THINKING>本分析用于测试 Reward 指标: [填写具体指标]</THINKING>\n\n"
    "### 经审理查明 ###\n"
    "[用“查明/认定/证明”字样描述关键事实]\n\n"
    "### 本院认为 ###\n"
    "[用“支持/构成/存在/合法/违法”等判定词给出法律评价]\n\n"
    "### 证据要点 ###\n"
    "[此处列出案情中关键的证据、物证或言辞证据]\n\n"
    "### 程序要点 ###\n"
    "[此处分析管辖、诉讼时效或举证责任分配]\n\n"
    "### 不利因素 ###\n"
    "[此处指出委托人可能面临的法律风险或证据缺失]\n\n"
    "### 结论倾向 ###\n"
    "[基于现有材料的初步法律研判]\n\n"
    "### 裁判结果 ###\n"
    "[简述可能裁判走向]"
)

TARGET_OUTCOME_WIN = "win"
TARGET_OUTCOME_LOSE = "lose"


def iter_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def dump_jsonl(path: Path, rows: Iterable[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def get_client() -> OpenAI:
    load_dotenv()
    api_key = os.getenv("SILICONFLOW_API_KEY") or os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("缺少 API Key。请在 .env 中设置 SILICONFLOW_API_KEY。")
    return OpenAI(base_url="https://api.siliconflow.cn/v1", api_key=api_key)


def llm_chat(
    client: OpenAI,
    messages: List[Dict[str, str]],
    temperature: float = 0.7,
    max_tokens: int = 1200,
    force_api: bool = False,
) -> str:
    try:
        response = client.chat.completions.create(
            model="deepseek-ai/DeepSeek-V3",
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content or ""
    except Exception:
        if force_api:
            raise
        return _offline_fallback_chat(messages)


def _offline_fallback_chat(messages: List[Dict[str, str]]) -> str:
    user_text = str(messages[-1].get("content", "")) if messages else ""
    if "输出" in user_text and "JSON" in user_text and "variant_type" in user_text:
        count = 3
        m = re.search(r"输出\s*(\d+)\s*条", user_text)
        if m:
            count = max(1, int(m.group(1)))
        is_win = "程序伪漏洞对比组" in user_text
        if is_win:
            metrics = ["程序时效", "送达瑕疵", "管辖异议", "程序合规性", "举证责任分配"]
            vtype = "程序伪漏洞对比组"
            case_txt = "员工实体证据较强，但单位主张送达程序合规且时效已过，双方围绕通知到达与仲裁期限产生争议。"
        else:
            metrics = ["证据链完整性", "关键证据合法性", "证据三性", "证明责任转移", "程序时效"]
            vtype = "证据翻盘对比组"
            case_txt = "员工补充了聊天记录、考勤与录音形成闭环证据链，针对原败诉点提出可采性与关联性抗辩。"
        payload = []
        for i in range(count):
            metric = metrics[i % len(metrics)]
            payload.append(
                {
                    "variant_type": vtype,
                    "test_metric": metric,
                    "thinking": f"<THINKING>本变种用于测试 Reward 指标: {metric}</THINKING>",
                    "scenario": f"{case_txt}（离线回退样本{i + 1}）",
                }
            )
        return json.dumps(payload, ensure_ascii=False)

    metric = "程序时效"
    m = re.search(r"该变种测试指标：([^\n。；;]+)", user_text)
    if m:
        metric = m.group(1).strip()
    return (
        f"<THINKING>本分析用于测试 Reward 指标: {metric}</THINKING>\n\n"
        "### 经审理查明 ###\n"
        "已查明单位存在调岗通知送达争议，员工提交聊天记录、通知截图、工时记录予以证明。\n\n"
        "### 本院认为 ###\n"
        "上述证据能够相互印证，足以证明程序瑕疵存在，且劳动关系争议具有可审查性。\n\n"
        "### 证据要点 ###\n"
        "聊天记录、邮件送达记录、考勤与录音形成证据链，证明关键事实存在。\n\n"
        "### 程序要点 ###\n"
        "围绕仲裁时效、通知送达和举证责任分配展开，重点审查程序合法性。\n\n"
        "### 不利因素 ###\n"
        "若录音来源合法性不足，可能影响部分证据采信力度。\n\n"
        "### 结论倾向 ###\n"
        "在现有证据基础上，员工主张更易获得支持。\n\n"
        "### 裁判结果 ###\n"
        "倾向支持员工关于程序瑕疵与证据补强后的请求。"
    )


def ensure_structured_sections(text: str) -> str:
    """
    如果模型偶发未按模板输出，自动补齐标题锚点，便于 EvidenceTracker 抓取结构信号。
    """
    required_sections = [
        "### 经审理查明 ###",
        "### 本院认为 ###",
        "### 证据要点 ###",
        "### 程序要点 ###",
        "### 不利因素 ###",
        "### 结论倾向 ###",
        "### 裁判结果 ###",
    ]
    output = text.strip()
    if "<THINKING>" not in output:
        output = (
            "<THINKING>本分析用于测试 Reward 指标: 证据链完整性/程序时效（自动补齐）</THINKING>\n\n"
            + output
        )
    for sec in required_sections:
        if sec not in output:
            output += f"\n\n{sec}\n[未明确提及]"
    return output


def parse_scenarios(text: str, want: int = 3) -> List[Dict[str, str]]:
    try:
        start = text.find("[")
        end = text.rfind("]") + 1
        if start != -1 and end > start:
            arr = json.loads(text[start:end])
            if isinstance(arr, list):
                cleaned: List[Dict[str, str]] = []
                for item in arr:
                    if isinstance(item, dict):
                        scenario = str(item.get("scenario", "")).strip()
                        thinking = str(item.get("thinking", "")).strip()
                        metric = str(item.get("test_metric", "")).strip()
                        variant_type = str(item.get("variant_type", "")).strip()
                        if scenario:
                            cleaned.append(
                                {
                                    "scenario": scenario,
                                    "thinking": thinking,
                                    "test_metric": metric,
                                    "variant_type": variant_type,
                                }
                            )
                    else:
                        scenario = str(item).strip()
                        if scenario:
                            cleaned.append(
                                {
                                    "scenario": scenario,
                                    "thinking": "",
                                    "test_metric": "",
                                    "variant_type": "",
                                }
                            )
                if cleaned:
                    return cleaned[:want]
    except Exception:
        pass

    # fallback: line split
    lines = [x.strip(" -\t") for x in text.splitlines() if x.strip()]
    return [{"scenario": line, "thinking": "", "test_metric": "", "variant_type": ""} for line in lines[:want]]


def ensure_thinking_block(text: str, test_metric: str, variant_type: str) -> str:
    metric = test_metric.strip() or "程序时效"
    purpose = variant_type.strip() or "对比组"
    payload = text.strip()
    if "<THINKING>" in payload and "</THINKING>" in payload:
        return payload
    return (
        f"<THINKING>本变种用于测试 Reward 指标: {metric}；分组类型: {purpose}</THINKING>\n\n"
        f"{payload}"
    )


def ensure_variant_tags(text: str, test_metric: str, variant_type: str) -> str:
    """
    强制每个变种包含 THINKING / CASE / STRATEGY 三类标签。
    """
    metric = test_metric.strip() or "程序时效"
    group = variant_type.strip() or "对比组"
    payload = text.strip()

    if "<CASE>" not in payload or "</CASE>" not in payload:
        payload = f"<CASE>{payload}</CASE>"
    if "<STRATEGY>" not in payload or "</STRATEGY>" not in payload:
        payload += f"\n<STRATEGY>本变种用于测试 Reward 指标: {metric}；策略分组: {group}</STRATEGY>"
    payload = ensure_thinking_block(payload, test_metric=metric, variant_type=group)
    return payload


def percentile(values: List[float], q: float) -> float:
    if not values:
        return 0.0
    if q <= 0:
        return min(values)
    if q >= 100:
        return max(values)
    sorted_vals = sorted(values)
    rank = (len(sorted_vals) - 1) * (q / 100.0)
    lower = int(rank)
    upper = min(lower + 1, len(sorted_vals) - 1)
    weight = rank - lower
    return sorted_vals[lower] * (1.0 - weight) + sorted_vals[upper] * weight


def case_context_from_seed(seed: Dict[str, Any]) -> str:
    # train.jsonl 常见字段：system/user/assistant/case_id/outcome
    return (
        f"case_id={seed.get('case_id', 'unknown')}\n"
        f"system={seed.get('system', '')}\n"
        f"user={seed.get('user', '')}\n"
        f"assistant={seed.get('assistant', '')}\n"
    )


def normalize_outcome(outcome: str) -> str:
    value = (outcome or "").strip().lower()
    if value.startswith("win"):
        return TARGET_OUTCOME_WIN
    if value.startswith("lose"):
        return TARGET_OUTCOME_LOSE
    if "avoid" in value or "flip" in value:
        return TARGET_OUTCOME_LOSE
    return "uncertain"


def select_seed_pool(
    seeds: List[Dict[str, Any]],
    target_win: int = 14,
    target_lose: int = 7,
) -> List[Dict[str, Any]]:
    seen_case: set = set()
    win_pool: List[Dict[str, Any]] = []
    lose_pool: List[Dict[str, Any]] = []
    fallback_pool: List[Dict[str, Any]] = []

    for seed in seeds:
        case_id = str(seed.get("case_id", "")).strip()
        if not case_id or case_id in seen_case:
            continue
        seen_case.add(case_id)

        outcome = normalize_outcome(str(seed.get("outcome", "")))
        enriched = dict(seed)
        enriched["_seed_outcome"] = outcome
        if outcome == TARGET_OUTCOME_WIN:
            win_pool.append(enriched)
        elif outcome == TARGET_OUTCOME_LOSE:
            lose_pool.append(enriched)
        else:
            fallback_pool.append(enriched)

    selected: List[Dict[str, Any]] = []
    selected.extend(win_pool[:target_win])
    selected.extend(lose_pool[:target_lose])

    # 若数据集不足 14/7，则使用剩余样本补齐，避免流程中断。
    if len(selected) < (target_win + target_lose):
        remaining = [x for x in win_pool[target_win:] + lose_pool[target_lose:] + fallback_pool]
        selected.extend(remaining[: (target_win + target_lose - len(selected))])

    return selected


class RewardScorer:
    def __init__(self) -> None:
        self.evidence_tracker = EvidenceTracker()
        self.element_matcher = LegalElementMatcher()
        self.syllogism_evaluator = SyllogismEvaluator()
        self.reward_adapter = RewardAdapter()

    def _extract_judicial_analysis(self, element_results: Dict[str, Any], evidence_state: EvidenceState) -> Dict[str, Any]:
        elements_satisfied: List[str] = []
        illegal_elements = element_results.get("illegal_termination_analysis", {}).get("elements", {})
        mutual_elements = element_results.get("mutual_agreement_analysis", {}).get("elements", {})
        for key, result in illegal_elements.items():
            if result.status == ElementStatus.SATISFIED:
                elements_satisfied.append(key)
        for key, result in mutual_elements.items():
            if result.status == ElementStatus.SATISFIED:
                elements_satisfied.append(key)

        summary = evidence_state.summarize()
        supporting_evidence = [k for k, v in summary.items() if v is True]
        confidence_map = getattr(evidence_state, "_evidence_confidence", {})
        return {
            "elements_satisfied": elements_satisfied,
            "supporting_evidence": supporting_evidence,
            "supporting_evidence_confidence": dict(confidence_map),
        }

    @staticmethod
    def auto_label(total_reward: float) -> str:
        if total_reward > 0.3:
            return "win"
        if total_reward < -0.3:
            return "lose"
        return "uncertain"

    def score(
        self,
        user_text: str,
        assistant_text: str,
        seed_outcome: Optional[str] = None,
    ) -> Tuple[float, Dict[str, Any], str]:
        dialogue_turn = {
            "system": SYSTEM_EXPERT,
            "user": user_text,
            "assistant": assistant_text,
        }
        initial_state = EvidenceState()
        evidence_state = self.evidence_tracker.update(initial_state, dialogue_turn)
        element_results = self.element_matcher.get_detailed_analysis(evidence_state)
        reasoning_result = self.syllogism_evaluator.evaluate(evidence_state, element_results)
        judicial_analysis = self._extract_judicial_analysis(element_results, evidence_state)
        normalized = normalize_outcome(seed_outcome or "")
        if normalized in {TARGET_OUTCOME_WIN, TARGET_OUTCOME_LOSE}:
            judicial_analysis["outcome"] = normalized

        reward_result = self.reward_adapter.adapt(reasoning_result, judicial_analysis)
        total_reward = float(reward_result.total_reward)
        breakdown = {
            "reward_components": reward_result.components,
            "reward_type": getattr(reward_result.reward_type, "value", str(reward_result.reward_type)),
            "explanation": reward_result.explanation,
            "elements_satisfied": reward_result.elements_satisfied,
            "supporting_evidence": reward_result.supporting_evidence,
            "missing_elements": reward_result.missing_elements,
        }
        return total_reward, breakdown, self.auto_label(total_reward)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate entropy-augmented scenarios via SiliconFlow API.")
    parser.add_argument("--input", default="data/train.jsonl", help="Seed dataset JSONL.")
    parser.add_argument("--output", default="data/augmented_train_data.jsonl", help="Output JSONL.")
    parser.add_argument("--variants", type=int, default=3, help="Variants per seed.")
    parser.add_argument("--variants-min", type=int, default=0, help="Min variants per seed (override --variants if >0).")
    parser.add_argument("--variants-max", type=int, default=0, help="Max variants per seed (override --variants if >0).")
    parser.add_argument("--max-seeds", type=int, default=0, help="Limit seed count for quick runs (0 means all).")
    parser.add_argument("--quantile", type=float, default=65.0, help="Dynamic reward quantile for filtering (e.g., 65 -> P65).")
    parser.add_argument("--target-win-seeds", type=int, default=14, help="Target number of unique win seeds.")
    parser.add_argument("--target-lose-seeds", type=int, default=7, help="Target number of unique lose seeds.")
    parser.add_argument("--force-api", action="store_true", help="Force API calls; fail on network/API errors.")
    parser.add_argument("--debug-log", action="store_true", help="Print per-sample reward components for audit.")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        raise FileNotFoundError(f"Seed file not found: {input_path}")

    seeds = list(iter_jsonl(input_path))
    seeds = select_seed_pool(seeds, target_win=args.target_win_seeds, target_lose=args.target_lose_seeds)
    if args.max_seeds > 0:
        seeds = seeds[: args.max_seeds]

    client = get_client()
    scorer = RewardScorer()
    candidates: List[Dict[str, Any]] = []

    for seed in tqdm(seeds, desc="Augmenting scenarios"):
        seed_case_id = str(seed.get("case_id", "seed_unknown"))
        case_context = case_context_from_seed(seed)
        seed_outcome = normalize_outcome(str(seed.get("_seed_outcome", seed.get("outcome", ""))))
        if args.variants_min > 0 and args.variants_max >= args.variants_min:
            variant_count = random.randint(args.variants_min, args.variants_max)
        else:
            variant_count = args.variants
        if seed_outcome == TARGET_OUTCOME_WIN:
            chaos_user = WIN_PSEUDO_VULNERABILITY_TEMPLATE.format(
                case_context=case_context,
                variant_count=variant_count,
            )
            variant_type = "程序伪漏洞对比组"
        else:
            chaos_user = LOSE_EVIDENCE_COMEBACK_TEMPLATE.format(
                case_context=case_context,
                variant_count=variant_count,
            )
            variant_type = "证据翻盘对比组"

        raw = llm_chat(
            client,
            messages=[
                {"role": "system", "content": SYSTEM_CHAOS},
                {"role": "user", "content": chaos_user},
            ],
            temperature=0.9,
            max_tokens=1600,
            force_api=args.force_api,
        )
        scenarios = parse_scenarios(raw, want=variant_count)
        if len(scenarios) < variant_count:
            for pad_idx in range(len(scenarios), variant_count):
                scenarios.append(
                    {
                        "scenario": f"补齐变种-{pad_idx + 1}：围绕{seed_case_id}构造可争议程序与证据事实。",
                        "thinking": "",
                        "test_metric": "",
                        "variant_type": variant_type,
                    }
                )

        for idx, scenario_item in enumerate(scenarios, start=1):
            metric = str(scenario_item.get("test_metric", "")).strip()
            declared_variant = str(scenario_item.get("variant_type", "")).strip() or variant_type
            scenario_body = str(scenario_item.get("scenario", "")).strip()
            scenario_thinking = str(scenario_item.get("thinking", "")).strip()
            scenario_text = ensure_variant_tags(
                f"{scenario_thinking}\n\n{scenario_body}".strip(),
                test_metric=metric,
                variant_type=declared_variant,
            )
            expert_user_prompt = (
                f"基于此案情：\n{scenario_text}\n\n"
                f"该变种测试指标：{metric or '程序时效'}。\n"
                "请输出：\n"
                "1) 必须先给出 <THINKING>，明确“本分析用于测试 Reward 指标: xxx”；\n"
                "2) 必须包含“经审理查明 / 本院认为 / 裁判结果”三段；\n"
                "3) 必须包含【证据要点、程序要点、不利因素、结论倾向】四段；\n"
                "4) 尽量使用“查明、认定、证明、支持、构成、存在”等判定词。"
            )
            assistant_text = llm_chat(
                client,
                messages=[
                    {"role": "system", "content": SYSTEM_EXPERT},
                    {"role": "user", "content": expert_user_prompt},
                ],
                temperature=0.5,
                max_tokens=1200,
                force_api=args.force_api,
            )
            assistant_text = ensure_structured_sections(assistant_text)
            assistant_text = ensure_thinking_block(
                assistant_text,
                test_metric=metric,
                variant_type=declared_variant,
            )

            reward, breakdown, outcome = scorer.score(
                scenario_text,
                assistant_text,
                seed_outcome=seed_outcome,
            )

            candidates.append(
                {
                    "case_id": f"{seed_case_id}_aug_{idx}",
                    "seed_case_id": seed_case_id,
                    "system": SYSTEM_EXPERT,
                    "user": scenario_text,
                    "assistant": assistant_text,
                    "strategy": declared_variant,
                    "test_metric": metric or "程序时效",
                    "seed_outcome": seed_outcome,
                    "outcome": outcome,
                    "reward": reward,
                    "total_reward": reward,
                    "reward_breakdown": breakdown,
                }
            )
            if args.debug_log:
                comp = breakdown.get("reward_components", {})
                print(
                    "[debug] "
                    f"case={seed_case_id}_aug_{idx} "
                    f"type={declared_variant} metric={metric or '程序时效'} "
                    f"reward={reward:.4f} "
                    f"Score_Fact={float(comp.get('score_fact', 0.0)):.4f} "
                    f"Score_Law={float(comp.get('score_law', 0.0)):.4f} "
                    f"Score_Process={float(comp.get('score_process', 0.0)):.4f} "
                    f"ring1={float(comp.get('process_ring1_pass', 0.0)):.0f} "
                    f"ring2={float(comp.get('process_ring2_pass', 0.0)):.0f} "
                    f"fact_law_penalty={float(comp.get('fact_law_penalty', 1.0)):.2f} "
                    f"law_conclusion_penalty={float(comp.get('law_conclusion_penalty', 1.0)):.2f}"
                )

    if not candidates:
        dump_jsonl(Path(args.output), [])
        print(f"Input seeds: {len(seeds)}")
        print("Generated candidates: 0")
        print("Saved rows: 0")
        print(f"Output path: {args.output}")
        return

    scores = [float(row.get("total_reward", 0.0)) for row in candidates]
    cutoff = percentile(scores, args.quantile)
    outputs = [row for row in candidates if float(row.get("total_reward", 0.0)) >= cutoff]
    if not outputs:
        best = max(candidates, key=lambda x: float(x.get("total_reward", 0.0)))
        outputs = [best]

    dump_jsonl(Path(args.output), outputs)
    print(f"Input seeds: {len(seeds)}")
    print(f"Generated candidates: {len(candidates)}")
    print(f"Dynamic cutoff (P{args.quantile:.0f}): {cutoff:.4f}")
    print(f"Saved rows (reward >= cutoff): {len(outputs)}")
    print(f"Output path: {args.output}")


if __name__ == "__main__":
    main()
