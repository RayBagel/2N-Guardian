"""
Quality checks for augmented training data.

Checks:
1) Diversity:
   - duplicate rate by content hash < 20%
   - template ratio by top character n-gram should not be too high
2) Reward distribution:
   - reward >= 0.0 baseline
   - reward >= 0.3 ratio >= 40%

Exit code:
0 => pass
1 => fail
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple


def iter_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", "", str(text))


def content_hash(row: Dict[str, Any]) -> str:
    payload = "||".join(
        [
            normalize_text(row.get("system", "")),
            normalize_text(row.get("user", "")),
            normalize_text(row.get("assistant", "")),
        ]
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def char_ngrams(text: str, n: int = 8) -> List[str]:
    t = normalize_text(text)
    if len(t) < n:
        return []
    return [t[i : i + n] for i in range(0, len(t) - n + 1)]


def compute_metrics(rows: List[Dict[str, Any]], ngram_n: int = 8) -> Dict[str, Any]:
    total = len(rows)
    if total == 0:
        return {
            "total": 0,
            "duplicate_rate": 1.0,
            "reward_nonneg_ratio": 0.0,
            "reward_ge_03_ratio": 0.0,
            "top_ngram": "",
            "top_ngram_ratio": 0.0,
            "watch_phrase_ratios": {},
        }

    # duplicate rate
    unique_hashes = len({content_hash(r) for r in rows})
    duplicate_rate = 1.0 - (unique_hashes / total)

    # reward distribution
    rewards = [float(r.get("total_reward", 0.0)) for r in rows]
    reward_nonneg_ratio = sum(1 for x in rewards if x >= 0.0) / total
    reward_ge_03_ratio = sum(1 for x in rewards if x >= 0.3) / total

    # template check by top n-gram in user text
    counter = Counter()
    for r in rows:
        user_text = str(r.get("user", ""))
        for ng in set(char_ngrams(user_text, n=ngram_n)):
            counter[ng] += 1
    if counter:
        top_ngram, top_count = counter.most_common(1)[0]
        top_ngram_ratio = top_count / total
    else:
        top_ngram, top_ngram_ratio = "", 0.0

    # specific phrase ratios
    watch_phrases = [
        "微信记录显示",
        "口头沟通",
        "聊天记录",
        "未提供书面",
    ]
    watch_phrase_ratios = {}
    for p in watch_phrases:
        hit = sum(1 for r in rows if p in str(r.get("user", "")))
        watch_phrase_ratios[p] = hit / total

    return {
        "total": total,
        "duplicate_rate": duplicate_rate,
        "reward_nonneg_ratio": reward_nonneg_ratio,
        "reward_ge_03_ratio": reward_ge_03_ratio,
        "top_ngram": top_ngram,
        "top_ngram_ratio": top_ngram_ratio,
        "watch_phrase_ratios": watch_phrase_ratios,
    }


def evaluate_pass(metrics: Dict[str, Any]) -> Tuple[bool, List[str]]:
    reasons: List[str] = []
    passed = True

    if metrics["duplicate_rate"] >= 0.20:
        passed = False
        reasons.append(f"duplicate_rate too high: {metrics['duplicate_rate']:.2%} (target < 20%)")

    if metrics["reward_ge_03_ratio"] < 0.40:
        passed = False
        reasons.append(f"reward>=0.3 ratio too low: {metrics['reward_ge_03_ratio']:.2%} (target >= 40%)")

    # heuristic template threshold
    if metrics["top_ngram_ratio"] > 0.35:
        passed = False
        reasons.append(
            f"template risk high: top ngram '{metrics['top_ngram']}' ratio={metrics['top_ngram_ratio']:.2%} (target <= 35%)"
        )

    return passed, reasons


def main() -> None:
    parser = argparse.ArgumentParser(description="Check augmented data quality gates.")
    parser.add_argument("--input", default="data/augmented_train_data.jsonl", help="Augmented dataset JSONL path.")
    parser.add_argument("--ngram-n", type=int, default=8, help="Character n-gram size for template detection.")
    parser.add_argument("--strict", action="store_true", help="Exit non-zero when gates fail.")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        raise FileNotFoundError(f"Input not found: {input_path}")

    rows = list(iter_jsonl(input_path))
    metrics = compute_metrics(rows, ngram_n=args.ngram_n)
    passed, reasons = evaluate_pass(metrics)

    print("=== Augmented Data Quality Report ===")
    print(f"total: {metrics['total']}")
    print(f"duplicate_rate: {metrics['duplicate_rate']:.2%}")
    print(f"reward_nonneg_ratio (>=0.0): {metrics['reward_nonneg_ratio']:.2%}")
    print(f"reward_ge_03_ratio (>=0.3): {metrics['reward_ge_03_ratio']:.2%}")
    print(f"top_ngram: {metrics['top_ngram']}")
    print(f"top_ngram_ratio: {metrics['top_ngram_ratio']:.2%}")
    print("watch_phrase_ratios:")
    for k, v in metrics["watch_phrase_ratios"].items():
        print(f"  {k}: {v:.2%}")

    if passed:
        print("QUALITY_GATE: PASS")
    else:
        print("QUALITY_GATE: FAIL")
        for r in reasons:
            print(f"- {r}")
        if args.strict:
            raise SystemExit(1)


if __name__ == "__main__":
    main()

