"""
LegalEnv: 法律推理 RL 交互环境

把 case 数据、策略生成、奖励计算封装为标准交互接口：
- reset(): 取一个 case
- step(action_output): 对单步动作计算奖励
- run_episode(n_steps=1): 多步模拟并返回轨迹
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple


class LegalEnv:
    """
    法律推理环境。

    Args:
        dataset: 案例数据集（list[dict]）
        policy: 策略对象或可调用对象
        reward_engine: 奖励引擎对象或可调用对象
    """

    def __init__(self, dataset: Sequence[Dict[str, Any]], policy: Any, reward_engine: Any):
        if not dataset:
            raise ValueError("dataset 不能为空")

        self.dataset: List[Dict[str, Any]] = list(dataset)
        self.policy = policy
        self.reward_engine = reward_engine

        self._cursor: int = 0
        self.current_case: Optional[Dict[str, Any]] = None
        self.reward_history: List[float] = []
        self.action_history: List[str] = []
        self.breakdown_history: List[Dict[str, Any]] = []

    def reset(self) -> Dict[str, Any]:
        """
        重置环境并返回一个 case（顺序轮转）。
        """
        case = self.dataset[self._cursor % len(self.dataset)]
        self._cursor += 1

        self.current_case = case
        self.reward_history = []
        self.action_history = []
        self.breakdown_history = []
        return case

    def step(self, action_output: str) -> Dict[str, Any]:
        """
        单步执行：
        - 输入 policy 生成的 reasoning 文本
        - 调用 reward_engine 计算 total_reward + breakdown
        """
        if self.current_case is None:
            self.reset()

        total_reward, reward_breakdown = self._compute_reward(action_output)

        self.action_history.append(action_output)
        self.reward_history.append(float(total_reward))
        self.breakdown_history.append(reward_breakdown)

        return {
            "case_id": self.current_case.get("case_id", "unknown"),
            "action": action_output,
            "reward": float(total_reward),
            "reward_breakdown": reward_breakdown,
        }

    def run_episode(self, n_steps: int = 1) -> Dict[str, Any]:
        """
        运行多轮模拟执行，返回轨迹与聚合结果。
        """
        if n_steps <= 0:
            raise ValueError("n_steps 必须大于 0")

        case = self.reset()

        for _ in range(n_steps):
            action_output = self._generate_action(case)
            self.step(action_output)

        return {
            "case_id": case.get("case_id", "unknown"),
            "action": self.action_history[-1] if self.action_history else "",
            "actions": list(self.action_history),
            "reward": list(self.reward_history),
            "total_reward": float(sum(self.reward_history)),
            "reward_breakdown": self.breakdown_history[-1] if self.breakdown_history else {},
            "reward_breakdown_history": list(self.breakdown_history),
        }

    def _generate_action(self, case: Dict[str, Any]) -> str:
        """
        调用 policy 生成动作。支持：
        - policy.generate(case=..., history=...)
        - policy(case=..., history=...)
        - policy(case)
        """
        history = list(self.action_history)

        if hasattr(self.policy, "generate"):
            return str(self.policy.generate(case=case, history=history))

        if callable(self.policy):
            try:
                return str(self.policy(case=case, history=history))
            except TypeError:
                return str(self.policy(case))

        raise TypeError("policy 必须是可调用对象，或提供 generate() 方法")

    def _compute_reward(self, action_output: str) -> Tuple[float, Dict[str, Any]]:
        """
        调用 reward_engine 计算奖励。支持：
        - reward_engine.evaluate(action_output=..., case=...)
        - reward_engine.compute(action_output=..., case=...)
        - reward_engine(action_output, case)

        返回:
            (total_reward, reward_breakdown)
        """
        case = self.current_case or {}
        raw: Any

        if hasattr(self.reward_engine, "evaluate"):
            raw = self.reward_engine.evaluate(action_output=action_output, case=case)
        elif hasattr(self.reward_engine, "compute"):
            raw = self.reward_engine.compute(action_output=action_output, case=case)
        elif callable(self.reward_engine):
            raw = self.reward_engine(action_output, case)
        else:
            raise TypeError("reward_engine 必须是可调用对象，或提供 evaluate()/compute() 方法")

        # 规范化输出
        if isinstance(raw, tuple) and len(raw) == 2:
            return float(raw[0]), dict(raw[1] or {})

        if isinstance(raw, dict):
            total_reward = float(raw.get("total_reward", raw.get("reward", 0.0)))
            breakdown = raw.get("reward_breakdown", raw.get("breakdown", {}))
            return total_reward, dict(breakdown or {})

        if hasattr(raw, "total_reward"):
            total_reward = float(getattr(raw, "total_reward"))
            breakdown = getattr(raw, "reward_breakdown", None)
            if breakdown is None:
                breakdown = getattr(raw, "components", {})
            return total_reward, dict(breakdown or {})

        return float(raw), {}
