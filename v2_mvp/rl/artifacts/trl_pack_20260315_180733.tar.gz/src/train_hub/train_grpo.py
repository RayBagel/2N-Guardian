"""
GRPO training entry for 24GB single-GPU setup (Qwen2.5-14B-Instruct).

This script is designed for ModelScope / notebook runtime with GPU.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

from datasets import Dataset

from src.logic_core.evidence.evidence_state import EvidenceState
from src.logic_core.evidence.evidence_tracker import EvidenceTracker
from src.logic_core.legal_reasoning.element_matcher import ElementStatus, LegalElementMatcher
from src.logic_core.legal_reasoning.syllogism_evaluator import SyllogismEvaluator
from src.logic_core.reward.reward_adapter import RewardAdapter


def iter_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            yield json.loads(line)


def build_prompt(system_text: str, user_text: str) -> str:
    return (
        f"<|system|>\n{system_text}\n"
        f"<|user|>\n{user_text}\n"
        f"<|assistant|>\n"
    )


def normalize_completion_text(completion: Any) -> str:
    if isinstance(completion, str):
        return completion
    if isinstance(completion, dict):
        if "content" in completion:
            return str(completion["content"])
        if "text" in completion:
            return str(completion["text"])
    if isinstance(completion, list):
        parts = []
        for item in completion:
            if isinstance(item, dict):
                parts.append(str(item.get("content", item.get("text", ""))))
            else:
                parts.append(str(item))
        return "".join(parts)
    return str(completion)


class RewardScorer:
    def __init__(self) -> None:
        self.evidence_tracker = EvidenceTracker()
        self.element_matcher = LegalElementMatcher()
        self.syllogism_evaluator = SyllogismEvaluator()
        self.reward_adapter = RewardAdapter()

    def _extract_judicial_analysis(
        self, element_results: Dict[str, Any], evidence_state: EvidenceState
    ) -> Dict[str, Any]:
        elements_satisfied = []
        illegal_elements = element_results.get("illegal_termination_analysis", {}).get("elements", {})
        mutual_elements = element_results.get("mutual_agreement_analysis", {}).get("elements", {})
        for key, result in illegal_elements.items():
            if result.status == ElementStatus.SATISFIED:
                elements_satisfied.append(key)
        for key, result in mutual_elements.items():
            if result.status == ElementStatus.SATISFIED:
                elements_satisfied.append(key)

        summary = evidence_state.summarize()
        supporting_evidence = [k for k, v in summary.items() if v is True]
        confidence_map = getattr(evidence_state, "_evidence_confidence", {})
        return {
            "elements_satisfied": elements_satisfied,
            "supporting_evidence": supporting_evidence,
            "supporting_evidence_confidence": dict(confidence_map),
        }

    def calculate_reward(
        self,
        system_text: str,
        user_text: str,
        assistant_text: str,
        outcome: str = "uncertain",
        ground_truth: str = "",
    ) -> float:
        dialogue_turn = {
            "system": system_text,
            "user": user_text,
            "assistant": assistant_text,
        }
        initial_state = EvidenceState()
        evidence_state = self.evidence_tracker.update(initial_state, dialogue_turn)
        element_results = self.element_matcher.get_detailed_analysis(evidence_state)
        reasoning_result = self.syllogism_evaluator.evaluate(evidence_state, element_results)
        judicial_analysis = self._extract_judicial_analysis(element_results, evidence_state)

        outcome = (outcome or "").lower()
        if outcome.startswith("win"):
            judicial_analysis["outcome"] = "win"
        elif outcome.startswith("lose"):
            judicial_analysis["outcome"] = "lose"
        else:
            judicial_analysis["outcome"] = "uncertain"

        gt = (ground_truth or "").lower()
        judicial_analysis["ground_truth"] = gt
        judicial_analysis["is_real_case"] = gt.endswith("_real")

        reward_result = self.reward_adapter.adapt(reasoning_result, judicial_analysis)
        return float(reward_result.total_reward)


def load_training_dataset(data_path: Path) -> Dataset:
    rows = []
    for row in iter_jsonl(data_path):
        system_text = str(row.get("system", "You are a professional labor law assistant."))
        user_text = str(row.get("user", "Please analyze this labor dispute case."))
        rows.append(
            {
                "prompt": build_prompt(system_text, user_text),
                "system": system_text,
                "user": user_text,
                "case_id": str(row.get("case_id", "")),
                "outcome": str(row.get("outcome", "uncertain")),
                "ground_truth": str(row.get("ground_truth", "")),
            }
        )
    if not rows:
        raise ValueError(f"No training rows found in: {data_path}")
    return Dataset.from_list(rows)


def build_reward_fn(scorer: RewardScorer):
    """
    Reward callback for GRPOTrainer.
    Supports common TRL signatures by using kwargs.
    """

    def reward_fn(prompts: Sequence[str], completions: Sequence[Any], **kwargs: Any) -> List[float]:
        systems = kwargs.get("system", [""] * len(completions))
        users = kwargs.get("user", [""] * len(completions))
        outcomes = kwargs.get("outcome", ["uncertain"] * len(completions))
        ground_truth = kwargs.get("ground_truth", [""] * len(completions))

        rewards = []
        for i, completion in enumerate(completions):
            completion_text = normalize_completion_text(completion)
            score = scorer.calculate_reward(
                system_text=str(systems[i]) if i < len(systems) else "",
                user_text=str(users[i]) if i < len(users) else "",
                assistant_text=completion_text,
                outcome=str(outcomes[i]) if i < len(outcomes) else "uncertain",
                ground_truth=str(ground_truth[i]) if i < len(ground_truth) else "",
            )
            rewards.append(score)
        return rewards

    return reward_fn


def main() -> None:
    parser = argparse.ArgumentParser(description="Train GRPO with Qwen2.5-14B-Instruct on 24GB GPU.")
    parser.add_argument("--data", default="data/clean_train_data.jsonl", help="Filtered JSONL training data.")
    parser.add_argument("--output", default="./output/checkpoint", help="Checkpoint output directory.")
    parser.add_argument("--max_steps", type=int, default=200, help="Training max steps.")
    args = parser.parse_args()

    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(f"Training data not found: {data_path}")

    try:
        from unsloth import FastLanguageModel
    except Exception as e:
        raise ImportError("unsloth is required. Install and run this script in GPU runtime.") from e

    try:
        from trl import GRPOConfig, GRPOTrainer
    except Exception as e:
        raise ImportError("trl with GRPOTrainer is required in runtime.") from e

    train_dataset = load_training_dataset(data_path)
    scorer = RewardScorer()
    reward_fn = build_reward_fn(scorer)

    model_name = "Qwen/Qwen2.5-14B-Instruct"
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=model_name,
        max_seq_length=1024,
        load_in_4bit=True,
        fast_inference=True,
    )

    model = FastLanguageModel.get_peft_model(
        model,
        r=16,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_alpha=16,
        lora_dropout=0.0,
        bias="none",
        use_gradient_checkpointing="unsloth",
        random_state=3407,
    )

    training_args = GRPOConfig(
        output_dir=args.output,
        max_steps=args.max_steps,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=4,
        learning_rate=1e-5,
        logging_steps=5,
        save_steps=50,
        bf16=True,
        num_generations=4,
        max_prompt_length=1024,
        max_completion_length=512,
        remove_unused_columns=False,
        report_to=[],
    )

    trainer = GRPOTrainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        train_dataset=train_dataset,
        reward_funcs=[reward_fn],
    )

    trainer.train()
    trainer.save_model(args.output)
    tokenizer.save_pretrained(args.output)
    print(f"Training complete. Checkpoint saved to: {args.output}")


if __name__ == "__main__":
    main()

