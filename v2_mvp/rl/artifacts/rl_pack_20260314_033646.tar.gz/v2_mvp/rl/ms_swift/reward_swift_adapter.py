"""
Swift reward adapter for 2N-Guardian.

Purpose:
- expose function-style reward entrypoints for different ms-swift versions
- reuse v2_mvp.rl.reward_manager.RewardManager as the single scoring backend
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from v2_mvp.rl.reward_manager import RewardManager

_MANAGER = RewardManager()


def _extract_sample(meta: Any) -> Dict[str, Any]:
    """
    Normalize metadata payload to sample dict.
    Accepts dict or JSON string.
    """
    if isinstance(meta, dict):
        return meta
    if isinstance(meta, str):
        meta = meta.strip()
        if not meta:
            return {}
        try:
            obj = json.loads(meta)
            if isinstance(obj, dict):
                return obj
        except Exception:
            return {}
    return {}


def score_one(completion: str, sample: Dict[str, Any]) -> float:
    result = _MANAGER.score(sample, completion)
    return float(result.total_reward)


def score_batch(completions: List[str], samples: List[Dict[str, Any]]) -> List[float]:
    if len(completions) != len(samples):
        raise ValueError("completions and samples length mismatch")
    return [score_one(c, s) for c, s in zip(completions, samples)]


# ---- Compatibility entrypoints for different swift integrations ----

def reward_fn(completions: List[str], metas: List[Any]) -> List[float]:
    """
    Generic function entrypoint: (completions, metas) -> rewards
    """
    samples = [_extract_sample(m) for m in metas]
    return score_batch(completions, samples)


def get_reward(completions: List[str], metas: List[Any]) -> List[float]:
    """Alias for frameworks expecting get_reward."""
    return reward_fn(completions, metas)


def compute_rewards(completions: List[str], metas: List[Any]) -> List[float]:
    """Alias for frameworks expecting compute_rewards."""
    return reward_fn(completions, metas)


def self_test(dataset_path: str = "v2_mvp/rl/data/eval_set.jsonl", limit: int = 3) -> None:
    rows = [json.loads(l) for l in Path(dataset_path).read_text(encoding="utf-8").splitlines() if l.strip()][:limit]
    completions = [str(r.get("reference_output") or r.get("reasoning") or "") for r in rows]
    rewards = reward_fn(completions, rows)
    print(f"self_test rows={len(rows)} rewards={[round(x,4) for x in rewards]}")


if __name__ == "__main__":
    self_test()
