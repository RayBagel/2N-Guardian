#!/usr/bin/env bash
set -euo pipefail

# 2N-Guardian GRPO launch script (Qwen3.5-27B + LoRA)
# Usage:
#   export SILICONFLOW_API_KEY=xxxx   # if your reward path needs API later
#   bash v2_mvp/rl/ms_swift/run_train.sh

PROJECT_ROOT="/Users/apple/2N-Guardian"
cd "$PROJECT_ROOT"

CONFIG_PATH="v2_mvp/rl/ms_swift/grpo_config.yaml"
DATASET_INFO="v2_mvp/rl/ms_swift/dataset_info.json"
REWARD_PATH="v2_mvp/rl/reward_manager.py"

if ! command -v swift >/dev/null 2>&1; then
  echo "[ERROR] swift command not found. Install ms-swift first: pip install ms-swift[llm] -U"
  exit 1
fi

if [ ! -f "$CONFIG_PATH" ]; then
  echo "[ERROR] missing config: $CONFIG_PATH"
  exit 1
fi
if [ ! -f "$DATASET_INFO" ]; then
  echo "[ERROR] missing dataset_info: $DATASET_INFO"
  exit 1
fi
if [ ! -f "$REWARD_PATH" ]; then
  echo "[ERROR] missing reward manager: $REWARD_PATH"
  exit 1
fi

# NOTE:
# Keep --model consistent with grpo_config.yaml
# If your swift version does not support --reward_funcs path directly,
# adapt to the corresponding custom reward registration argument.
swift rlhf \
  --rlhf_type grpo \
  --model Qwen/Qwen3.5-27B-Instruct \
  --dataset 2n-guardian-grpo \
  --custom_register_path "$DATASET_INFO" \
  --reward_funcs "$REWARD_PATH" \
  --train_type lora \
  --lora_rank 16 \
  --lora_alpha 32 \
  --lora_dropout 0.05 \
  --per_device_train_batch_size 1 \
  --gradient_accumulation_steps 16 \
  --learning_rate 5e-7 \
  --num_train_epochs 1 \
  --max_new_tokens 512 \
  --warmup_ratio 0.03 \
  --logging_steps 1 \
  --save_steps 50 \
  --eval_steps 50 \
  --output_dir v2_mvp/rl/output/qwen3_5_27b_grpo_lora
